https://mester.inf.elte.hu/

A megoldást mindenképp fel kell tölteni a mesterre is.

Fontos, hogy az szlgbp.hu-s azonosítóddal jelentkezz be, mikor feltöltöd a megoldást!

-Szint: Kezdő
-Téma: Programozási tételek: Kiválogatás
-Feladat: 5. Drága fenyőfák *

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mester_kereses_15
{
    class Program
    {
        static void Main(string[] args)
        {
            // Beolvasás

            string sor = Console.ReadLine();
            string[] tömb = sor.Split(' ');

            int N = int.Parse(tömb[0]);
            int K = int.Parse(tömb[1]);

            int[] Ar = new int[N];

            for (int i = 0; i < N; i++)
            {
                Ar[i] = int.Parse(Console.ReadLine());
            }


            // Feldolgozás

            int j = 0;
            while (j < N && !(Ar[j] < K))
            {
                j++;
            }
            if (j == N)
            {
                j = -1;
            }
            else
            {
                j = j + 1;
            }


            //Kiírás

            Console.WriteLine(j);
        }
    }
}

﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
        void Sűrű_bokor(int év, double méret)
        {
            if (év > 0) 
            {
                Sűrű_bokor(év - 1, 0.5 * méret);
                Előre(méret / 2);
                Balra(30);
                Sűrű_bokor(év - 1, 0.5 * méret);
                Jobbra(30);
                Sűrű_bokor(év - 1, 0.5 * méret);
                Előre(méret / 2);
                Jobbra(30);
                Sűrű_bokor(év - 1, 0.5 * méret);
                Balra(30);
                Sűrű_bokor(év - 1, 0.5 * méret);
                Hátra(méret);
            }
        }
        void FELADAT()
		{
            Sűrű_bokor(4, 100);
		}
	}
}

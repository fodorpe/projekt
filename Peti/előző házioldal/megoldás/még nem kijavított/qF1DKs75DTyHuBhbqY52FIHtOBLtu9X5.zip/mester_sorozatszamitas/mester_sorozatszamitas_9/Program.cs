﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mester_sorozatszamitas_9
{
    class Program
    {
        static void Main(string[] args)
        {

            // Beolvasás

            int N = int.Parse(Console.ReadLine());
            int[] F = new int[N];
            for (int i = 0; i < N; i++)
            {
                string sor = Console.ReadLine();
                string[] tömb = sor.Split(' ');
                F[i] = int.Parse(tömb[0]);
            }

            // Feldolgozás

            int fel = 0;
            for (int i = 0; i < N; i++)
            {
                fel = fel + F[i];
            }

            // Kiírás

            Console.WriteLine(fel);
        }
    }
}

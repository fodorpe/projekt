﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
        void sokszog_belul(int év, double méret)
        {
            if (év == 1 || év == 2)
            {
                Előre(méret);
            }
            else if (év == 3)
            {
                for (int i = 0; i < 3; i++)
                {
                    Előre(méret);
                    Jobbra(120);
                }
            }
            else if (év > 3)
            {
                for (int i = 0; i < év; i++)
                {
                    sokszog_belul(év - (év - 2), méret);
                    Jobbra(360 / év);
                    Jobbra((((év - 2 * 180 / év) - (év - 3 * 180 / (év - 1))) / 2) / 3);
                    sokszog_belul(év - 1, méret / 2);
                    Balra((((év - 2 * 180 / év) - (év - 3 * 180 / (év - 1))) / 2) / 3);
                }
            }
        }

        void FELADAT()
        {
            Tollat(fel);
            Előre(150);
            Tollat(le);

            sokszog_belul(5, 100);
        }
    }
}

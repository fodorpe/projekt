﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
        void kitölt(double meret, double fok, Color szin)
        {
            using (new Rajzol(false))
            {
                using (new Átmenetileg(Fordulj, fok))
                {
                    using (new Átmenetileg(Előre, meret))
                    {
                        Tölt(szin, false);
                    }
                }
            }
        }

        void oldalaz(double meret, int i)
        {
            using (new Átmenetileg(Fordulj, -90 * i))
            {
                Előre(meret);
            }
        }

        void szinesnegyzet(double meret, int irany, Color szin)
        {
            for (int i = 0; i < 4; i++)
            {
                Előre(meret);
                Fordulj(-90*irany);
            }
            kitölt(meret / 2, -45*irany, szin);
        }

        void alapelem(double meret)
        {
            for (int i = 0; i < 4; i++)
            {
                Előre(meret / 2);
                szinesnegyzet(meret / 4, -1, Color.Brown);
                Fordulj(-90);
            }
            kitölt(meret / 4, -45, Color.DarkOrange);
        }

        void sor(double meret, int verzio)
        {
            for (int i = 0; i < 7; i++)
            {
                if (i % 2 == 0 + verzio)
                {
                    alapelem(meret);
                    using (new Rajzol(false))
                    {
                        Hátra(meret / 4);
                        oldalaz(meret / 2, 1);
                    }
                }
                else
                {
                    szinesnegyzet(meret, 1, Color.Orange);
                    oldalaz(meret, 1);
                    Előre(meret / 4);
                }
            }
            using (new Rajzol(false))
            {
                oldalaz(meret * 5.25, -1);
                Előre(meret / 4);

            }
        }
        void parketta(double meret)
        {
            for (int i = 0; i < 5; i++)
            {
                if (i % 2 == 0)
                {
                    sor(meret, 0);
                }
                else
                {
                    sor(meret, 1);
                }
                using (new Rajzol(false))
                {
                    Előre(meret / 2);
                }
            }
            using (new Rajzol(false))
            {
                Hátra(meret * 3.75);
            }
        }
        void FELADAT()
		{

            Teleport(közép.X-150, közép.Y+50, észak);

            parketta(50);

		}
	}
}

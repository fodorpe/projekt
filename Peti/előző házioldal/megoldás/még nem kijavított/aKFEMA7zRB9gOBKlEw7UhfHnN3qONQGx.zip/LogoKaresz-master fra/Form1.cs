﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
		void Fra_fraktál(int év, double meret)
		{
			if (év == 1)
			{
				Előre(meret);
			}
			else if (év > 1)
			{
				Fra_fraktál(év - 1, meret / 2);
				Jobbra(72);
				Fra_fraktál(év - 1, meret / 2);
				Balra(144);
				Fra_fraktál(év - 1, meret / 2);
				Balra(72);
				Fra_fraktál(év - 1, meret / 2);
				Jobbra(72);
				Fra_fraktál(év - 1, meret / 2);
				Jobbra(72);
				Fra_fraktál(év - 1, meret / 2);
			}
		}
		void Fra(int év, double meret)
		{
			for (int i = 0; i < 1; i++)
			{
				Fra_fraktál(év, meret);
			}
		}

		void Fra5(int év, double meret)
		{
			for (int i = 0; i < 5; i++)
			{
				Fra_fraktál(év, meret);
				Jobbra(72);
			}
		}

		void FELADAT()
		{
			Teleport(közép.X - 100, közép.Y, észak);


			using (new Frissítés(false))
			{
				Fra5(5, 50);
			}

		}
	}
}

﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
        void szép_fa(int é, double meret)
        {
            if (é == 1)
            {
                Tollszín(Color.LightGreen);
            }
            if (é == 2)
            {
                Tollszín(Color.DarkGreen);
            }
            if (é > 2)
            {
                Tollszín(Color.Brown);
            }
            if (é > 2)
            {
                Tollvastagság(é / 2);
            }
            if (é > 0)
            {
                Tollat(le);
                Előre(meret);
                Balra(30);
                szép_fa(é - 1, meret * 0.5);
                Jobbra(30);
                szép_fa(é - 1, meret * 0.6);
                Jobbra(30);
                szép_fa(é - 1, meret * 0.5);
                Balra(30);
                Tollat(fel);
                Hátra(meret);
            }
        }
        void FELADAT()
        {
            szép_fa(5, 100);
        }
    }
}

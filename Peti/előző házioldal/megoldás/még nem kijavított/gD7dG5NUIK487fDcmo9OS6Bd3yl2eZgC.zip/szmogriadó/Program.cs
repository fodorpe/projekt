﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace szmogriadó
{
    class Program
    {
        static void Main(string[] args)
        {

            int N = int.Parse(Console.ReadLine());
            List<int> Napok = new List<int>(N);
            for (int i = 0; i < N; i++)
            {
                int nap = int.Parse(Console.ReadLine());
                Napok.Add(nap);
            }
            List<int> SZ = new List<int>();
            for (int i = 1; i < N; i++)
            {
                if (Napok[i] > 100 && Napok[i - 1] <= 100)
                {
                    SZ.Add(i + 1);
                }
            }
            Console.Write(SZ.Count + " ");
            for (int i = 0; i < SZ.Count; i++)
            {
                Console.Write(SZ[i] + " ");
            }
        }
    }
}

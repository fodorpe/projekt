﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Különböző_árú_borok
{
    class Program
    {
        static bool Van_e(List<int> L, int D)
        {
            int i = 0;
            while (i < L.Count && L[i] != D)
            {
                i++;
            }
            return i < L.Count ? true : false;
        }

        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int[] K = new int[N];
            List<int> E = new List<int> { };
            for (int i = 0; i < N; i++)
            {
                string sor = Console.ReadLine();

                string[] sortomb = sor.Split(' ');

                K[i] = int.Parse(sortomb[1]);


                if (Van_e(E, K[i]) != true)
                {
                    E.Add(K[i]);
                }

            }


            Console.WriteLine(E.Count);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Lineáris_keresések
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] tömb = File.ReadAllLines("input.txt");

            int[] számtömb = new int[tömb.Length];

            for (int i = 0; i < tömb.Length; i++)
            {
                számtömb[i] = int.Parse(tömb[i]);
            }

            /// 1. Feladat
            {
                int i = 0;
                while (i < számtömb.Length && számtömb[i] != 123) 
                {
                    i++;
                }

                bool megoldás = i < számtömb.Length;
                Console.WriteLine($" 1. Szerepel-e az adatok között 123-as szám? {megoldás}");
            }

            ///2. Feladat
            { 
                int i = 0;
                while (i < számtömb.Length && számtömb[i] % 111 != 0)
                {
                    i++;
                }

                Console.WriteLine($" 2. Adj meg egy, a listában található 111-gyel osztható számot! (ilyen biztosan van a listában!): {számtömb[i]}");
            }

            ///3. Feladat
            {
                int i = 0;
                while (i < számtömb.Length && (számtömb[i] % 100 != 0 || számtömb[i] == 0))
                {
                    i++;
                }

                if (i < számtömb.Length)
                {
                    Console.WriteLine($" 3. Add meg az  első 2 db nullára végződő szám indexét! {i}");
                }
                else
                {
                    Console.WriteLine($" 3. Add meg az  első 2 db nullára végződő szám indexét! {-1}");
                }
            }

            ///4.Feladat
            {
                int i = számtömb.Length - 1;
                while (i >= 0 && számtömb[i] % 200 != 0)
                {
                    i--;
                }
                Console.WriteLine($" 4. Add meg az utolsó  200-zal osztható szám indexét! {i}");
            }

            ///5.Feladat
            {
                int i = 0;
                while (i < számtömb.Length && (számtömb[i] % 100 != 25))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine($" 5. Szerepel-e az adatok között olyan szám, ami 25-re végződik? Igen");
                }
                else
                {
                    Console.WriteLine($" 5. Szerepel-e az adatok között olyan szám, ami 25-re végződik? Nem");
                }
            }

            ///6.Feladat
            {
                int i = számtömb.Length - 1;
                while (i >= 0 && !(számtömb[i] < 10))
                {
                    i--;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine($" 6. Add meg az utolsó olyan számot, ami 1-jegyű! {i}");
                }

            }

            ///7.Feladat
            {
                int i = 0;
                while (i < számtömb.Length && !(számtömb[i] < 0))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine($" 7. Add meg az első negatív szám indexét!(ha nincs, adj vissza -1-et! {i} ");
                }
                else
                {
                    Console.WriteLine($" 7. Add meg az első negatív szám indexét!(ha nincs, adj vissza -1-et! {-1}");
                }
            }

            ///8.Feladat
            {
                int i = számtömb.Length - 1;
                while (i >= 0 && !(számtömb[i] < -40))
                {
                    i--;
                }
                if (i >= 0)
                {
                    Console.WriteLine($" 8. Add meg az utolsó -40-nél kisebb szám indexét!(ha nincs ilyen, adj vissza -1-et!) {i}");

                }
                else
                {
                    Console.WriteLine($" 8. Add meg az utolsó -40-nél kisebb szám indexét!(ha nincs ilyen, adj vissza -1-et!) {-1}");
                }
            }

                Console.ReadKey();
        }
    }
}

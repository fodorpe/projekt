﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
        void toltes(double fok, double meret, Color szin)
        {
            Tollat(fel);
            Fordulj(fok);
            Előre(meret);
            Tölt(szin);
            Hátra(meret);
            Fordulj(-fok);
            Tollat(le);
        }
        void negyzet(double meret, Color szin)
        {
            for (int i = 0; i < 4; i++)
            {
                Előre(meret);
                Fordulj(90);
            }
            toltes(45, meret / 2, szin);
        }
        void mozaikdarab(double meret, Color szin1, Color szin3)
        {
            negyzet(meret, szin1);
            Előre(meret);
            negyzet(meret / 2, szin3);
            Hátra(meret);
        }
        void mozaikoszlop(double meret, int db, Color szin1, Color szin2, Color szin3)
        {
            for (int i = 0; i < db; i++)
            {
                if (i % 2 == 0)
                {
                    mozaikdarab(meret, szin1, szin3);
                }
                else
                {
                    mozaikdarab(meret, szin2, szin3);
                }
                Előre(meret);
                Fordulj(90);
                Előre(meret / 2);
                Fordulj(-90);
            }
            for (int i = 0; i < db; i++)
            {
                Fordulj(90);
                Hátra(meret / 2);
                Fordulj(-90);
                Hátra(meret);
            }
        }
        void mozaik(double meret, int oszlopszam, int sorszam, Color szin1, Color szin2, Color szin3)
        {
            Fordulj(-30);
            for (int i = 0; i < oszlopszam; i++)
            {
                if (i % 2 == 0)
                {
                    mozaikoszlop(meret, sorszam, szin1, szin2, szin3);
                }
                else
                {
                    mozaikoszlop(meret, sorszam, szin2, szin1, szin3);
                }
                Tollat(fel);
                Előre(meret / 2);
                Fordulj(-90);
                Előre(meret);
                Fordulj(90);
                Tollat(le);
            }
            for (int i = 0; i < oszlopszam; i++)
            {
                Tollat(fel);
                Fordulj(-90);
                Hátra(meret);
                Fordulj(90);
                Hátra(meret / 2);
                Tollat(le);
            }
        }
        void FELADAT()
		{
			
			Teleport(közép.X-150, közép.Y+50, észak);

            mozaik(50, 5, 3, Color.Aqua, Color.Gray, Color.Blue);

		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mester_megszamolas_2
{
    class Program
    {
        static void Main(string[] args)
        {

            // Beolvasás

            int N = int.Parse(Console.ReadLine());
            int[] K = new int[N];
            for (int i = 0; i < N; i++)
            {
                K[i] = int.Parse(Console.ReadLine());
            }


            // Feldolgozás

            int db = 0;
            for (int i = 0; i < N; i++)
            {
                if (K[i] > 0)
                {
                    db++;
                }
            }

            // Kiírás
            Console.WriteLine(db);
        }
    }
}

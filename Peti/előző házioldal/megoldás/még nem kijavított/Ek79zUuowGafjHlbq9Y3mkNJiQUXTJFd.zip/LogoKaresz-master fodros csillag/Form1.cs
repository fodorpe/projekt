﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
		void Fraktál(int év, double meret)
		{
			if (év == 1)
			{
				Előre(meret);
			}
			else if (év > 1)
			{
				Fraktál(év - 1, meret / 3);
				Jobbra(60);
				Fraktál(év - 1, meret / 3);
				Balra(120);
				Fraktál(év - 1, meret / 3);
				Fraktál(év - 1, meret / 3);
				Jobbra(120);
				Fraktál(év - 1, meret / 3);
				Balra(60);
			}
		}
		void Egész(int db, int év, double meret)
		{
			for (int i = 0; i < db; i++)
			{
				Fraktál(év, meret);
				Jobbra(72);
			}
		}
		void FELADAT()
		{
			Teleport(közép.X - 100, közép.Y, észak);
			Jobbra(75);


			using (new Frissítés(false))
			{
				Egész(5, 6, 100);
				
			}

		}
	}
}

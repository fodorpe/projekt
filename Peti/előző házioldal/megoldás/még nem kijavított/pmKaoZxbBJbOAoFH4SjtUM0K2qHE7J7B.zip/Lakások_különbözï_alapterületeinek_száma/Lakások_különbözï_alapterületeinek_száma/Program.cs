﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lakások_különböző_alapterületeinek_száma
{
    class Program
    {
        static bool vane(List<int> l, int n)
        {
            int i = 0;
            while (i < l.Count && l[i] != n)
            {
                i++;
            }
            return i < l.Count ? true : false;
        }
        static void Main(string[] args)
        {

            // beolvasás
            int N = int.Parse(Console.ReadLine());
            int[] T = new int[N];

            List<int> K = new List<int> { };

            for (int i = 0; i < N; i++)
            {
                string sor = Console.ReadLine();
                string[] sortomb = sor.Split(' ');
                T[i] = int.Parse(sortomb[0]);

                // feldolgozás
                if (vane(K, T[i]) != true)
                {
                    K.Add(T[i]);
                }
            }

            // kiírás
            Console.WriteLine(K.Count);
        }
    }
}

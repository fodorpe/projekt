﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
        void C_görbe(int év, double méret)
        {
            if (év == 1)
            {
                Előre(méret);
            }
            else if (év > 1)
            {
                Jobbra(90);
                C_görbe(év - 1, méret / 3);
                Balra(90);
                C_görbe(év - 1, méret / 3);
                C_görbe(év - 1, méret / 3);
                Balra(90);
                C_görbe(év - 1, méret / 3);
                Jobbra(90);
            }
        }
        void FELADAT()
		{
            Teleport(közép.X - 100, közép.Y, észak);
            Jobbra(90);


            using (new Frissítés(false))
            {
                C_görbe(7, 2000);
            }
        }
	}
}

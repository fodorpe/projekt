﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _3000J
{
    class Program
    {

        static int angolcsoporttestver(List<Tanuló> l, string ancsop)
        {
            int db = 0;
            for (int i = 0; i < l.Count; i++)
            {
                if (l[i].ancsop == ancsop)
                {
                    db += l[i].testverszam;
                }
            }
            return db;
        }
        static double masodiknyelvatlag(List<Tanuló> l, string mnyelv)
        {
            double testdb = 0;
            double db = 0;
            for (int i = 0; i < l.Count; i++)
            {
                if (l[i].mnyelv == mnyelv)
                {
                    testdb += l[i].testverszam;
                    db++;
                }
            }
            return testdb / db;
        }
        static void nevsorelsoutolso(List<Tanuló> l, string ancsop)
        {
            int i = 0;
            while (i < l.Count && l[i].ancsop != ancsop)
            {
                i++;
            }
            Console.WriteLine(l[i].nev);
            int j = l.Count - 1;
            while (j >= 0 && l[j].ancsop != ancsop)
            {
                j--;
            }
            Console.WriteLine(l[j].nev);
        }

        static int TanulóIndexkeresés(string név, List<Tanuló> tanulók)
        {
            bool megvan = false;
            int i = 0;
            while (!megvan && i < tanulók.Count)
            {
                if (tanulók[i].nev == név)
                {
                    megvan = true;
                }
                i++;
            }
            return i - 1;
        }

        static List<Tanuló> Csoporttársai(int index, List<Tanuló> tanulók)
        {
            List<Tanuló> csoporttársai = new List<Tanuló>();
            string keresettcsoport = tanulók[index].ancsop;
            for (int i = 0; i < tanulók.Count; i++)
            {
                if (tanulók[i].ancsop == keresettcsoport && i != index)
                {
                    csoporttársai.Add(tanulók[i]);
                }
            }
            return csoporttársai;
        }

        static void CsoporttársaiNévAlapján(string név, List<Tanuló> tanulók)
        {
            List<string> CsoporttársaiNévAlapján = new List<string>();
            int ix = TanulóIndexkeresés(név, tanulók);
            if (tanulók[ix].nev != név)
            {
                Console.WriteLine("Nincs ilyen diák az osztályban.");
            }
            else
            {
                List<Tanuló> csoporttársak = Csoporttársai(ix, tanulók);

                for (int k = 0; k < csoporttársak.Count; k++)
                {
                    Console.WriteLine($" {csoporttársak[k].nev}");
                }

            }
        }

        static bool tartalmazza(List<string> l, string tartalmazandó)
        {
            int i = 0;
            while (i < l.Count && !(l[i] == tartalmazandó))
            {
                i++;
            }
            return i < l.Count;
        }

        class Tanuló
        {
            public string kod;
            public string nev;
            public string matinfcsop;
            public string ancsop;
            public string mnyelv;
            public string nem;
            public int egyuttlakok;
            public int testverszam;
        }

        static void Main(string[] args)
        {
            List<Tanuló> tanulók = new List<Tanuló>();

            string[] sorok = File.ReadAllLines("input.txt");

            for (int i = 0; i < sorok.Length; i++)
            {
                string[] sortömb = sorok[i].Split(';');
                Tanuló t = new Tanuló();
                t.kod = sortömb[0];
                t.nev = sortömb[1];
                t.matinfcsop = sortömb[2];
                t.ancsop = sortömb[3];
                t.mnyelv = sortömb[4];
                t.nem = sortömb[5];
                t.egyuttlakok = int.Parse(sortömb[6]);
                t.testverszam = int.Parse(sortömb[7]);
                tanulók.Add(t);
            }
            #region 1
            Console.WriteLine(" 1. Hány diák tanul az osztályban?");
            {
                Console.WriteLine($" {tanulók.Count}");
            }
            #endregion

            #region 2
            Console.WriteLine(" 2. Hány fiú tanul az osztályban?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].nem == "F")
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 3
            Console.WriteLine(" 3. Hány lány tanul az osztályban?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].nem == "L")
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 4
            Console.WriteLine(" 4. Hány olyan diák van, akiknek több mint 1 testvére van?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].testverszam > 1)
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 5
            Console.WriteLine(" 5. Gyűjtse ki azon diákok nevét, akiknek több mint 1 testvérük van!");
            {
                string[] tömb = new string[tanulók.Count];
                int j = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].testverszam > 1)
                    {
                        tömb[j] = tanulók[i].nev;
                        j++;
                    }
                }

                for (int i = 0; i < j; i++)
                {
                    Console.WriteLine($" {tömb[i]}");
                }
            }
            #endregion

            #region 6
            Console.WriteLine(" 6. Hány olyan diák van, akiknek több mint 2 testvére van?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].testverszam > 2)
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 7
            Console.WriteLine(" 7. Gyűjtse ki azon diákok nevét, akiknek több mint 2 testvérük van!");
            {
                string[] tömb = new string[tanulók.Count];
                int j = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].testverszam > 2)
                    {
                        tömb[j] = tanulók[i].nev;
                        j++;
                    }
                }

                for (int i = 0; i < j; i++)
                {
                    Console.WriteLine($" {tömb[i]}");
                }
            }
            #endregion

            #region 8
            Console.WriteLine(" 8. Hány olyan diák van, akik a 2. idegen nyelvként a németet tanulják?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].mnyelv == "német")
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 9
            Console.WriteLine(" 9. Gyűjtse ki azon fiú diákok nevét, akik a 2. idegen nyelvként a németet tanulják!");
            {
                string[] tömb = new string[tanulók.Count];
                int j = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].nem == "F" && tanulók[i].mnyelv == "német")
                    {
                        tömb[j] = tanulók[i].nev;
                        j++;
                    }
                }

                for (int i = 0; i < j; i++)
                {
                    Console.WriteLine($" {tömb[i]}");
                }
            }
            #endregion

            #region 10
            Console.WriteLine(" 10. Hány diák tanul az egyes angol csoportban?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].ancsop == "1. Sió")
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 11
            Console.WriteLine(" 11. Hány diák tanul a kettes angol csoportban?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].ancsop == "2. Bán")
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 12
            Console.WriteLine(" 12. Hány diák tanul az alfa matematika csoportban?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].matinfcsop == "alfa")
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 13
            Console.WriteLine(" 13. Hány diák tanul a beta matematika csoportban?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].matinfcsop == "beta")
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 14
            Console.WriteLine(" 14. Hány lány tanul az alfa matematika csoportban?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].nem == "L" && tanulók[i].matinfcsop == "alfa")
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 15
            Console.WriteLine(" 15. Hány lány tanul a beta matematika csoportban?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].nem == "L" && tanulók[i].matinfcsop == "beta")
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 16
            Console.WriteLine(" 16. Hány fiú tanul az alfa matematika csoportban?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].nem == "F" && tanulók[i].matinfcsop == "alfa")
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 17
            Console.WriteLine(" 17. Hány fiú tanul a beta matematika csoportban?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].nem == "F" && tanulók[i].matinfcsop == "beta")
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 18
            Console.WriteLine(" 18. Van-e olyan diák, aki a 2. idegen nyelvként oroszt tanul?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].mnyelv == "orosz")
                    {
                        db++;
                    }
                }

                if (db == 0)
                {
                    Console.WriteLine(" Nincs");
                }
                if (db > 0)
                {
                    Console.WriteLine(" Van");
                }
            }
            #endregion

            #region 19
            Console.WriteLine(" 19. Van-e olyan diák, aki a 2. idegen nyelvként olaszt tanul?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].mnyelv == "olasz")
                    {
                        db++;
                    }
                }

                if (db == 0)
                {
                    Console.WriteLine(" Nincs");
                }
                if (db > 0)
                {
                    Console.WriteLine(" Van");
                }
            }
            #endregion

            #region 20
            Console.WriteLine(" 20. Van-e olyan diák, aki a 2. idegen nyelvként spanyolt tanul?");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].mnyelv == "spanyol")
                    {
                        db++;
                    }
                }

                if (db == 0)
                {
                    Console.WriteLine(" Nincs");
                }
                if (db > 0)
                {
                    Console.WriteLine(" Van");
                }
            }
            #endregion

            #region 21
            Console.WriteLine(" 21. Mekkora a legnagyobb család az osztályban?");
            {
                int legnagyobb = tanulók[0].egyuttlakok;
                for (int i = 1; i < tanulók.Count; i++)
                {
                    if (tanulók[i].egyuttlakok > legnagyobb)
                    {
                        legnagyobb = tanulók[i].egyuttlakok;
                    }
                }
                Console.WriteLine($" {legnagyobb}");
            }
            #endregion

            #region 22
            Console.WriteLine(" 22. Írjuk ki az egyik olyan diák nevét akinek e legtöbb testvére van!");
            {
                int legnagyobb = tanulók[0].testverszam;
                string nev = tanulók[0].nev;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].testverszam > legnagyobb)
                    {
                        tanulók[i].egyuttlakok = legnagyobb;
                        tanulók[i].nev = nev;
                    }
                }
                Console.WriteLine($" {nev}");
            }
            #endregion

            #region 23
            Console.WriteLine(" 23. Gyűjtse ki azon lány diákok nevét, akik az egyes vagy kettes angol csoportban vannak!");
            {
                string[] tömb = new string[tanulók.Count];
                int j = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].nem == "L" && tanulók[i].ancsop == "1. Sió" || tanulók[i].ancsop == "2. Bán")
                    {
                        tömb[j] = tanulók[i].nev;
                        j++;
                    }
                }

                for (int i = 0; i < j; i++)
                {
                    Console.WriteLine($" {tömb[i]}");
                }
            }
            #endregion

            #region 24
            Console.WriteLine(" 24. Gyűjtse ki azon fiú diákok nevét, akik a hármas vagy négyes angol csoportban vannak és 0 vagy 2 testvérük van!");
            {
                string[] tömb = new string[tanulók.Count];
                int j = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].nem == "F" && tanulók[i].ancsop == "3. Joó" || tanulók[i].ancsop == "4. Kis" && tanulók[i].testverszam == 0 || tanulók[i].testverszam == 2)
                    {
                        tömb[j] = tanulók[i].nev;
                        j++;
                    }
                }

                for (int i = 0; i < j; i++)
                {
                    Console.WriteLine($" {tömb[i]}");
                }
            }
            #endregion

            #region 25
            Console.WriteLine(" 25. Viszonylag kevés azon családok száma, ahol az együttlakók száma és a testvérek száma között nem három a különbség. Adja meg a számukat!");
            {
                int db = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (!(tanulók[i].egyuttlakok - tanulók[i].testverszam == 3))
                    {
                        db++;
                    }
                }

                Console.WriteLine($" {db}");
            }
            #endregion

            #region 26
            Console.WriteLine(" 26. Dári Dóra hiányzott a legutóbbi angol órán, szeretné bepótolni a hiányzást. Adja meg azon tanulók nevét, akik vele azonos angol csoportba járnak.");
            {
                CsoporttársaiNévAlapján("Dári Dóra", tanulók);
            }
            #endregion

            #region 27
            Console.WriteLine(" 27. Avon Mór  hiányzott a legutóbbi angol órán, szeretné bepótolni a hiányzást. Adja meg azon tanulók nevét, akik vele azonos angol csoportba járnak.");
            {
                CsoporttársaiNévAlapján("Avon Mór", tanulók);
            }
            #endregion

            #region 28
            Console.WriteLine(" 28. Zúz Mara hiányzott a legutóbbi angol órán, szeretné bepótolni a hiányzást. Adja meg azon tanulók nevét, akik vele azonos angol csoportba járnak.");
            {
                CsoporttársaiNévAlapján("Zúz Mara", tanulók);
            }
            #endregion

            #region 29
            Console.WriteLine(" 29. Citad Ella hiányzott a legutóbbi angol órán, szeretné bepótolni a hiányzást. Adja meg azon tanulók nevét, akik vele azonos angol csoportba járnak.");
            {
                CsoporttársaiNévAlapján("Citad Ella", tanulók);
            }
            #endregion

            #region 30
            Console.WriteLine(" 30. Hát Izsák hiányzott a legutóbbi angol órán, szeretné bepótolni a hiányzást. Adja meg azon tanulók nevét, akik vele azonos angol csoportba járnak.");
            {
                CsoporttársaiNévAlapján("Hát Izsák", tanulók);
            }
            #endregion

            #region 31
            Console.WriteLine(" 31.	A spanyol vagy a német nyelvet tanulják-e többben az osztáyban?");
            {
                int spanyol = 0;
                int német = 0;
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (tanulók[i].mnyelv == "Spanyol")
                    {
                        spanyol++;
                    }
                    if (tanulók[i].mnyelv == "Német")
                    {
                        német++;
                    }
                }
                if (német > spanyol)
                {
                    Console.WriteLine(" A németet");
                }
                if (spanyol > német)
                {
                    Console.WriteLine(" A spanyolt");
                }
                if (német == spanyol)
                {
                    Console.WriteLine(" Ugyanannyian tanulják");
                }
            }
            #endregion

            #region 32
            Console.WriteLine("32) Kérjen be a felhasználótól egy nyelvet és írja ki, az adott nyelvet tanulók névsorát!");
            string bekértnyelv = Console.ReadLine();
            List<string> bekértnyelvettanulók_nevei = new List<string>();
            for (int i = 0; i < tanulók.Count; i++)
            {
                if (tanulók[i].mnyelv == bekértnyelv)
                {
                    bekértnyelvettanulók_nevei.Add(tanulók[i].nev);
                }
            }
            for (int i = 0; i < bekértnyelvettanulók_nevei.Count; i++)
            {
                Console.WriteLine($" {bekértnyelvettanulók_nevei[i]}");
            }
            #endregion

            #region 33
            Console.WriteLine(" 33. Hány különböző második idegen nyelvet lehet tanulni?");
            {
                List<string> mnyelvek = new List<string>();
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (!tartalmazza(mnyelvek, tanulók[i].mnyelv))
                    {
                        mnyelvek.Add(tanulók[i].mnyelv);
                    }
                }
                Console.WriteLine($" {mnyelvek.Count}");
            }
            #endregion

            #region 34
            {
                Console.WriteLine(" 34. Add meg a különböző matematika/informatika szerinti csoportbontások neveit!");
                List<string> matcsop = new List<string>();
                for (int i = 0; i < tanulók.Count; i++)
                {
                    if (!tartalmazza(matcsop, tanulók[i].matinfcsop))
                    {
                        matcsop.Add(tanulók[i].matinfcsop);
                    }
                }
                for (int i = 0; i < matcsop.Count; i++)
                {
                    Console.WriteLine($" {matcsop[i]}");
                }
            }
            #endregion

            #region 35
            Console.WriteLine(" 35. Melyik angol nyelvi csoportba hányan járnak?");
            {
                List<string> ancsop = new List<string>();
                for (int i = 0; i < tanulók.Count; i++)
                {
                    ancsop.Add(tanulók[i].ancsop);
                }
                Dictionary<string, int> angolszam = new Dictionary<string, int>();
                foreach (string szo in ancsop)
                {
                    if (angolszam.ContainsKey(szo))
                    {
                        angolszam[szo] += 1;
                    }
                    else
                    {
                        angolszam[szo] = 1;
                    }
                }
                foreach (string kulcs in angolszam.Keys)
                {
                    Console.WriteLine($" {kulcs} : {angolszam[kulcs]}");
                }
            }
            #endregion

            #region 36
            Console.WriteLine(" 36. Csoportosítsuk az együttlakók száma szerint a diákokat! Melyik csoportban hányan vannak?");
            {
                List<int> együttlakok = new List<int>();
                for (int i = 0; i < tanulók.Count; i++)
                {
                    együttlakok.Add(tanulók[i].egyuttlakok);
                }
                Dictionary<int, int> egyutlakokszam = new Dictionary<int, int>();
                foreach (int szam in együttlakok)
                {
                    if (egyutlakokszam.ContainsKey(szam))
                    {
                        egyutlakokszam[szam] += 1;
                    }
                    else
                    {
                        egyutlakokszam[szam] = 1;
                    }
                }
                foreach (int kulcs in egyutlakokszam.Keys)
                {
                    Console.WriteLine($" Együtlakók száma {kulcs} : {egyutlakokszam[kulcs]}");
                }
            }
            #endregion

            #region 37
            {
                Console.WriteLine(" 37. Melyik a leggyakrabban előforduló testvérszám?");
                List<int> testverszam = new List<int>();
                for (int i = 0; i < tanulók.Count; i++)
                {
                    testverszam.Add(tanulók[i].egyuttlakok);
                }
                Dictionary<int, int> testverek = new Dictionary<int, int>();
                foreach (int szam in testverszam)
                {
                    if (testverek.ContainsKey(szam))
                    {
                        testverek[szam] += 1;
                    }
                    else
                    {
                        testverek[szam] = 1;
                    }
                }
                int max = 0;
                int j = 0;
                foreach (int kulcs in testverek.Keys)
                {
                    if (max < testverek[kulcs])
                    {
                        max = testverek[kulcs];
                        j = kulcs;
                    }
                }
                Console.WriteLine($" {j}");
            }
            #endregion
            
            #region 38
            {
                Console.WriteLine(" 38. Add meg angolcsoportonként, hogy melyik csoportban hány testvére van összesen az oda járó embereknek!");
                Console.WriteLine(" 1. Sió");
                Console.WriteLine(angolcsoporttestver(tanulók, "1. Sió"));
                Console.WriteLine(" 2. Bán");
                Console.WriteLine(angolcsoporttestver(tanulók, "2. Bán"));
                Console.WriteLine(" 3. Joó");
                Console.WriteLine(angolcsoporttestver(tanulók, "3. Joó"));
                Console.WriteLine(" 4. Kis");
                Console.WriteLine(angolcsoporttestver(tanulók, "4. Kis"));
            }
            #endregion

            #region 39
            {
                Console.WriteLine(" 39. Add meg második nyelvi csoportonként, hogy melyik csoportban átlagosan hány testvére van az oda járó embereknek!");
                Console.WriteLine(" Spanyol");
                Console.WriteLine(masodiknyelvatlag(tanulók, "spanyol"));
                Console.WriteLine(" Német");
                Console.WriteLine(masodiknyelvatlag(tanulók, "német"));
            }
            #endregion

            #region 40
            {
                Console.WriteLine(" 40. Add meg angolcsoportonként a névsorban első és utolsó diák nevét!");
                Console.WriteLine(" 1. Sió");
                nevsorelsoutolso(tanulók, "1. Sió");
                Console.WriteLine(" 2. Bán");
                nevsorelsoutolso(tanulók, "2. Bán");
                Console.WriteLine(" 3. Joó");
                nevsorelsoutolso(tanulók, "3. Joó");
                Console.WriteLine(" 4. Kis");
                nevsorelsoutolso(tanulók, "4. Kis");
            }
            #endregion


            Console.ReadKey();
        }
    }
}

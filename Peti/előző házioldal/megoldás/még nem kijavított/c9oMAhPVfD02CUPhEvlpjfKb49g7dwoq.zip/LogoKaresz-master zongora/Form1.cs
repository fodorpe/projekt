﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
		void teglalap(double nagyoldalhossz, double kisoldalhossz)
		{
			for (int i = 0; i < 2; i++)
			{
				Előre(nagyoldalhossz);
				Fordulj(-90);
				Előre(kisoldalhossz);
				Fordulj(-90);
			}
		}
		void kisbillentyu(double nagyoldalhossz, double kisoldalhossz)
		{
			for (int j = 0; j < 2; j++)
			{
				Előre(kisoldalhossz * 0.6);
				Fordulj(90);
				Előre(nagyoldalhossz * 0.6);
				Fordulj(90);
			}
			Előre((kisoldalhossz * 0.6) / 2);
			Előre(kisoldalhossz - (kisoldalhossz * 0.6) / 2);
		}
		void feketeszinezes(double hossz)
		{
			Tollat(fel);
			Előre(hossz);
			Tölt(Color.Black);
			Tollat(le);
		}
		void billentyublokk(double nagyoldalhossz, double kisoldalhossz)
		{
			Előre(nagyoldalhossz);
			Fordulj(90);
			Előre(kisoldalhossz - (kisoldalhossz * 0.6) / 2);
			for (int i = 0; i < 3; i++)
			{
				kisbillentyu(nagyoldalhossz, kisoldalhossz);
			}
			Előre(kisoldalhossz);
			kisbillentyu(nagyoldalhossz, kisoldalhossz);
			for (int j = 0; j < 2; j++)
			{
				Előre(kisoldalhossz * 0.6);
				Fordulj(90);
				Előre(nagyoldalhossz * 0.6);
				Fordulj(90);
			}
			Előre((kisoldalhossz * 0.6) / 2);
			/**/
			Előre(kisoldalhossz);
			Fordulj(90);
			Előre(nagyoldalhossz / 3);
			Fordulj(90);
			for (int i = 0; i < 2; i++)
			{
				feketeszinezes(kisoldalhossz);
			}
			Tollat(fel);
			Előre(kisoldalhossz);
			Tollat(le);
			for (int i = 0; i < 3; i++)
			{
				feketeszinezes(kisoldalhossz);
			}
			Tollat(fel);
			Hátra(kisoldalhossz * 6);
			//Pihi(10000);
			Tollat(le);
			Fordulj(-90);
			Előre((nagyoldalhossz / 3) * 2);
			Fordulj(180);
			/**/
			for (int i = 0; i < 7; i++)
			{
				teglalap(nagyoldalhossz, kisoldalhossz);
				Fordulj(-90);
				Előre(kisoldalhossz);
				Fordulj(90);
			}
			Fordulj(90);
			Előre(kisoldalhossz * 7);
			Fordulj(-90);
		}
		void zongora(double nagyoldalhossz, double kisoldalhossz, int blockszam)
		{
			for (int i = 0; i < blockszam; i++)
			{
				billentyublokk(nagyoldalhossz, kisoldalhossz);
			}
			Fordulj(-90);
			Előre(kisoldalhossz * 7);
			Fordulj(90);
		}
		void FELADAT()
		{
			
			Teleport(közép.X+300, közép.Y+50, észak);

			zongora(75, 10, 6);

		}
	}
}

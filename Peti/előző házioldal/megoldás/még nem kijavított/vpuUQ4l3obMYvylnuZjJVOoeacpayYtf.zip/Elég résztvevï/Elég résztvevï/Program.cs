﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elég_résztvevő
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int[] R = new int[N];
            for (int j = 0; j < N; j++)
            {
                Console.ReadLine();
                Console.ReadLine();
                R[j] = int.Parse(Console.ReadLine());
            }
            int i = 0;
            int sum = 0;
            while (i < R.Length && (sum += R[i]) < 10000)
            {
                i++;
            }
            Console.WriteLine(i < R.Length ? i + 1 : -1);
        }
    }
}

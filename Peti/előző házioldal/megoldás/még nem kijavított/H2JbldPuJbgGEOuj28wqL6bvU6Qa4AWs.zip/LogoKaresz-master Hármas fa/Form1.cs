﻿using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
        void Hármas_fa(int év, double méret)
        {
            if (év > 0) 
            {
                Előre(méret);
                Balra(60);
                Hármas_fa(év - 1, 0.67 * méret);
                Jobbra(60);
                Hármas_fa(év - 1, 0.67 * méret);
                Jobbra(60);
                Hármas_fa(év - 1, 0.67 * méret);
                Balra(60);
                Hátra(méret);
            }
        }
        void FELADAT()
		{
            Hármas_fa(7, 100);
		}
	}
}

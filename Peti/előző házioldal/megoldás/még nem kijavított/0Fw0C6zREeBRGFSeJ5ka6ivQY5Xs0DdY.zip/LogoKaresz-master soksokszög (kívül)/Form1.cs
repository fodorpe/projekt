﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
		void soksokszög(int szög, int  meret)
		{
			for (int i = 0; i < szög; i++)
			{
				Előre(meret);
				Fordulj(((180 / szög) + (180 / (szög - 1)) - 180));
				if (szög > 3)
				{
					soksokszög(szög - 1, meret / 2);
				}
				Fordulj(-((180 / szög) + (180 / (szög - 1)) - 180));
				Fordulj(360 / szög);
			}
		}
		void FELADAT()
		{
			
		    Teleport(közép.X-100, közép.Y+50, észak);

			soksokszög(8, 80);

		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mester_eldontes_3
{
    class Program
    {
        static void Main(string[] args)
        {

            // Beolvasás

            int N = int.Parse(Console.ReadLine());
            int[] szuletes = new int[N];

            for (int i = 0; i < N; i++)
            {
                string sor = Console.ReadLine();
                string[] tömb = sor.Split(' ');
                szuletes[i] = int.Parse(tömb[0]);
            }

            int K = int.Parse(Console.ReadLine());


            // Feldolgozás

            int j = 0;
            while (j < N && !(K - szuletes[j] > 6574))
            {
                j++;
            }


            // Kiírás

            if (j < N)
            {
                Console.WriteLine("VAN");
            }
            else
            {
                Console.WriteLine("NINCS");
            }
        }
    }
}

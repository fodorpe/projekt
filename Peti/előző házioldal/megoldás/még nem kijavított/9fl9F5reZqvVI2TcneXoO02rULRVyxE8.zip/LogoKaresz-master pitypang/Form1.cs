﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
        void Pitypang(int év, double mÉret)
        {
            if (év > 0)
            {
                Előre(mÉret);
                Balra(60);
                Pitypang(év - 1, mÉret * 0.5);
                if (év > 1)
                {
                    for (int i = 0; i < év - 1; i++)
                    {
                        Jobbra(120 / (év - 1));
                        Pitypang(év - 1, mÉret * 0.5);
                    }
                }
                else
                {
                    Jobbra(120);
                    Pitypang(év - 1, mÉret * 0.5);
                }
                Balra(60);
                Hátra(mÉret);
            }
        }
        void FELADAT()
		{
            Pitypang(4, 100);
		}
	}
}

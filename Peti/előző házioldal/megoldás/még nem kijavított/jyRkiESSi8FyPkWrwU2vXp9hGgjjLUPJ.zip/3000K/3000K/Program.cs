﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _3000K
{
    class Program
    {
        #region Class
        class orszag_helyezese
        {
            public string ország;
            public int helyezés;
            public int év;
            public string hely;
        }
        #endregion


        #region F1_5 
        private static void f1_5(List<orszag_helyezese> VB, string orszag)
        {
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].ország == orszag)
                {
                    Console.WriteLine($" {VB[i].helyezés}	{VB[i].év}	{VB[i].hely}");
                }
            }
        }
        #endregion

        #region F6
        private static void f6(List<orszag_helyezese> VB)
        {
            Console.Write(" Ide írj be egy országot: ");
            string orszag = Console.ReadLine();
            for (int i = 0; i < VB.Count; i++)
            {
                if (orszag == VB[i].ország)
                {
                    Console.WriteLine($" {VB[i].helyezés}	{VB[i].év}	{VB[i].hely}");
                }
            }
            Console.WriteLine(" (Ha nem ír ki semmit, akkor vagy nincs ilyen ország az adatok között, vagy rosszul lett beírva)");
        }
        #endregion

        #region F7_12
        private static void f7_12(List<orszag_helyezese> VB, int ev)
        {
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].év > ev && VB[i].év < ev + 10)
                {
                    if (VB[i].helyezés == 1)
                    {
                        Console.WriteLine($" {VB[i].ország}	{VB[i].év}");
                    }
                }
            }
        }
        #endregion

        #region F13_17
        private static void f13_17(List<orszag_helyezese> VB, string orszag)
        {
            int db = 0;
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].ország == orszag)
                {
                    db++;
                }
            }
            Console.WriteLine($" {db}");
        }
        #endregion

        #region F18
        private static void f18(List<orszag_helyezese> VB)
        {
            Console.Write(" Ide írj be egy országot: ");
            string orszag = Console.ReadLine();
            int db = 0;
            for (int i = 0; i < VB.Count; i++)
            {
                if (orszag == VB[i].ország)
                {
                    db++;
                }
            }
            Console.WriteLine($" Ennyiszer szerepelt vb-n: {db}");
        }
        #endregion

        #region F19_23
        private static void f19_23(List<orszag_helyezese> VB, int ev)
        {
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].év == ev && VB[i].helyezés == 1)
                {
                    Console.WriteLine($" {VB[i].ország}");
                }
            }
        }
        #endregion

        #region F24_29
        private static void f24_29(List<orszag_helyezese> VB, string orszag)
        {
            int db = 0;
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].ország == orszag && VB[i].helyezés == 2)
                {
                    db++;
                }
            }
            Console.WriteLine($" {db}");
        }
        #endregion

        #region F30
        private static void f30(List<orszag_helyezese> VB)
        {
            Console.Write(" Ide írj egy évszámot: ");
            string bemenet = Console.ReadLine();
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].év == int.Parse(bemenet) && VB[i].helyezés == 1)
                {
                    Console.WriteLine($" {VB[i].ország}");
                }
            }
        }
        #endregion

        #region F31
        private static void f31(List<orszag_helyezese> VB)
        {
            int min = VB[0].év;
            for (int i = 1; i < VB.Count; i++)
            {
                if (VB[i].év < min)
                {
                    min = VB[i].év;
                }
            }
            Console.WriteLine($" {min}");
        }
        #endregion

        #region F32_36
        private static void f32_36(List<orszag_helyezese> VB, string orszag)
        {
            int db = 0;
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].ország == orszag && VB[i].helyezés == 1)
                {
                    db++;
                }
            }
            Console.WriteLine($" {db}");
        }
        #endregion

        #region F37_41
        private static void f37_41(List<orszag_helyezese> VB, string orszag)
        {
            int legjobb = 40;
            for (int i = 1; i < VB.Count; i++)
            {
                if (VB[i].ország == orszag && legjobb > VB[i].helyezés)
                {
                    legjobb = VB[i].helyezés;
                }
            }
            if (legjobb == 40)
            {
                legjobb = -1;
            }
            Console.WriteLine($" {legjobb}");
        }
        #endregion

        #region F42
        private static void f42(List<orszag_helyezese> VB)
        {
            Console.WriteLine(" Ide írj be egy országot: ");
            string bemenet = Console.ReadLine();
            int legjobb = 40;
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].ország == bemenet && VB[i].helyezés < legjobb)
                {
                    legjobb = VB[i].helyezés;
                }
            }
            if (legjobb == 40)
            {
                legjobb = -1;
            }
            Console.WriteLine($" A legjobb helyezése: {legjobb}");
        }
        #endregion

        #region F43
        private static void f43(List<orszag_helyezese> VB)
        {
            Console.WriteLine(" Ide írj be egy országot: ");
            string bemenet = Console.ReadLine();
            int db = 0;
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].ország == bemenet && VB[i].helyezés == 1)
                {
                    db++;
                }
            }
            Console.WriteLine($" Ennyiszer nyert vb-t: {db}");
        }
        #endregion

        #region F44_48
        private static void f44_48(List<orszag_helyezese> VB, string orszag)
        {
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].hely == orszag && VB[i].helyezés == 1)
                {
                    Console.WriteLine($" {VB[i].ország}	 {VB[i].év}");
                }
            }
        }
        #endregion

        #region F49
        private static void f49(List<orszag_helyezese> VB)
        {
            Console.WriteLine(" Ide írj be egy országot: ");
            string bemenet = Console.ReadLine();
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].hely == bemenet && VB[i].helyezés == 1)
                {
                    Console.WriteLine($" {VB[i].ország}	{VB[i].év}");
                }
            }
        }
        #endregion

        #region F50_52
        private static void f50_52(List<orszag_helyezese> VB, string orszag)
        {
            int j = 0;
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].ország == orszag && VB[i].helyezés < 3)
                {
                    j = 0;
                    while (j < VB.Count && !(VB[i].év == VB[j].év && VB[j].helyezés == 1))
                    {
                        j++;
                    }
                    if (j < VB.Count)
                    {
                        Console.WriteLine($" {VB[j].ország}	 {VB[j].év}");
                    }
                }
            }
        }
        #endregion

        #region F53_56
        private static void f53_56(List<orszag_helyezese> VB, string orszag)
        {
            int j = 0;
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].ország == orszag && VB[i].helyezés < 3)
                {
                    j = 0;
                    while (j < VB.Count && !(VB[j].ország != orszag && VB[j].helyezés < 3 && VB[i].év == VB[j].év))
                    {
                        j++;
                    }
                    if (j < VB.Count)
                    {
                        Console.WriteLine($" {VB[j].ország}	 {VB[j].év}");
                    }
                }
            }
        }
        #endregion

        #region F57
        private static void f57(List<orszag_helyezese> VB)
        {
            Console.WriteLine(" Ide írj be egy országot: ");
            string bemenet = Console.ReadLine();
            int j = 0;
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].ország == bemenet && VB[i].helyezés < 3)
                {
                    j = 0;
                    while (j < VB.Count && !(VB[j].ország != bemenet && VB[j].helyezés < 3 && VB[i].év == VB[j].év))
                    {
                        j++;
                    }
                    if (j < VB.Count)
                    {
                        Console.WriteLine($" {VB[j].ország}	 {VB[j].év}");
                    }
                }
            }
        }
        #endregion

        #region F58
        private static void f58(List<orszag_helyezese> VB)
        {
            Dictionary<string, int> bajnok_csapatok = new Dictionary<string, int>();
            List<string> lehetseges_csapatok = new List<string>();
            for (int i = 0; i < VB.Count; i++)
            {
                if (!lehetseges_csapatok.Contains(VB[i].ország))
                {
                    lehetseges_csapatok.Add(VB[i].ország);

                }
            }
            for (int i = 0; i < lehetseges_csapatok.Count; i++)
            {
                bajnok_csapatok[lehetseges_csapatok[i]] = 0;
            }
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].helyezés == 1)
                {
                    bajnok_csapatok[VB[i].ország]++;
                }
            }

            foreach (string kulcs in bajnok_csapatok.Keys)
            {
                if (bajnok_csapatok[kulcs] > 1)
                {
                    Console.WriteLine($" {kulcs}");
                }
            }
        }
        #endregion

        #region F59
        private static void f59(List<orszag_helyezese> VB)
        {
            Dictionary<string, int> bajnok_orszagok = new Dictionary<string, int>();
            List<string> lehetseges_orszagok = new List<string>();
            for (int i = 0; i < VB.Count; i++)
            {
                if (!lehetseges_orszagok.Contains(VB[i].hely))
                {
                    lehetseges_orszagok.Add(VB[i].hely);
                }
            }
            for (int i = 0; i < lehetseges_orszagok.Count; i++)
            {
                bajnok_orszagok[lehetseges_orszagok[i]] = 0;
            }
            for (int i = 0; i < VB.Count; i++)
            {
                bajnok_orszagok[VB[i].hely]++;
            }

            foreach (string kulcs in bajnok_orszagok.Keys)
            {
                if (bajnok_orszagok[kulcs] > 1)
                {
                    Console.WriteLine($" {kulcs}");
                }
            }
        }
        #endregion

        #region F60
        private static void f60(List<orszag_helyezese> VB)
        {
            Dictionary<string, int> bajnok_csapatok = new Dictionary<string, int>();
            List<string> lehetseges_csapatok = new List<string>();
            for (int i = 0; i < VB.Count; i++)
            {
                if (!lehetseges_csapatok.Contains(VB[i].ország))
                {
                    lehetseges_csapatok.Add(VB[i].ország);

                }
            }
            for (int i = 0; i < lehetseges_csapatok.Count; i++)
            {
                bajnok_csapatok[lehetseges_csapatok[i]] = 0;
            }
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].helyezés == 1)
                {
                    bajnok_csapatok[VB[i].ország]++;
                }
            }
            int max = 0;
            for (int i = 1; i < bajnok_csapatok.Count; i++)
            {
                if (bajnok_csapatok[lehetseges_csapatok[i]] > max)
                {
                    max = bajnok_csapatok[lehetseges_csapatok[i]];
                }
            }

            for (int i = 0; i < bajnok_csapatok.Count; i++)
            {
                if (bajnok_csapatok[lehetseges_csapatok[i]] == max)
                {
                    Console.WriteLine($" {lehetseges_csapatok[i]} : {max}");
                }
            }
        }
        #endregion

        #region F61
        private static void f61(List<orszag_helyezese> VB)
        {
            Dictionary<string, int> bajnok_orszagok = new Dictionary<string, int>();
            Dictionary<string, int> volt_orszagok = new Dictionary<string, int>();
            List<string> lehetseges_orszagok = new List<string>();
            for (int i = 0; i < VB.Count; i++)
            {
                if (!lehetseges_orszagok.Contains(VB[i].hely))
                {
                    lehetseges_orszagok.Add(VB[i].hely);
                    volt_orszagok[VB[i].hely] = 0;

                }
            }
            for (int i = 0; i < lehetseges_orszagok.Count; i++)
            {
                bajnok_orszagok[lehetseges_orszagok[i]] = 0;
            }
            for (int i = 0; i < VB.Count; i++)
            {
                if (volt_orszagok.ContainsKey(VB[i].hely) && !volt_orszagok.ContainsValue(VB[i].év))
                {
                    bajnok_orszagok[VB[i].hely]++;
                    volt_orszagok[VB[i].hely] = VB[i].év;
                }

            }
            int max = 0;
            for (int i = 1; i < bajnok_orszagok.Count; i++)
            {
                if (bajnok_orszagok[lehetseges_orszagok[i]] > max)
                {
                    max = bajnok_orszagok[lehetseges_orszagok[i]];
                }
            }

            for (int i = 0; i < bajnok_orszagok.Count; i++)
            {
                if (bajnok_orszagok[lehetseges_orszagok[i]] == max)
                {
                    Console.WriteLine($" {lehetseges_orszagok[i]} : {max}");
                }
            }
        }
        #endregion

        #region F62
        private static void f62(List<orszag_helyezese> VB)
        {
            Dictionary<string, int> bajnok_csapatok = new Dictionary<string, int>();
            List<string> lehetseges_csapatok = new List<string>();
            for (int i = 0; i < VB.Count; i++)
            {
                if (!lehetseges_csapatok.Contains(VB[i].ország))
                {
                    lehetseges_csapatok.Add(VB[i].ország);
                }
            }
            for (int i = 0; i < lehetseges_csapatok.Count; i++)
            {
                bajnok_csapatok[lehetseges_csapatok[i]] = 0;
            }
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].helyezés == 2)
                {
                    bajnok_csapatok[VB[i].ország]++;
                }
            }
            int max = 0;
            for (int i = 1; i < bajnok_csapatok.Count; i++)
            {
                if (bajnok_csapatok[lehetseges_csapatok[i]] > max)
                {
                    max = bajnok_csapatok[lehetseges_csapatok[i]];
                }
            }

            for (int i = 0; i < bajnok_csapatok.Count; i++)
            {
                if (bajnok_csapatok[lehetseges_csapatok[i]] == max)
                {
                    Console.WriteLine($" {lehetseges_csapatok[i]} : {max}");
                }
            }
        }
        #endregion

        #region F63
        private static void f63(List<orszag_helyezese> VB)
        {
            Dictionary<string, int> csapatok = new Dictionary<string, int>();
            List<string> lehetseges_csapatok = new List<string>();
            for (int i = 0; i < VB.Count; i++)
            {
                if (!lehetseges_csapatok.Contains(VB[i].ország))
                {
                    lehetseges_csapatok.Add(VB[i].ország);
                }
            }
            for (int i = 0; i < lehetseges_csapatok.Count; i++)
            {
                csapatok[lehetseges_csapatok[i]] = 0;
            }
            for (int i = 0; i < VB.Count; i++)
            {
                csapatok[VB[i].ország]++;
            }

            foreach (string kulcs in csapatok.Keys)
            {
                Console.WriteLine($" {kulcs} : {csapatok[kulcs]}");
            }
        }
        #endregion

        #region F64
        private static void f64(List<orszag_helyezese> VB)
        {
            Dictionary<string, int> orszagok = new Dictionary<string, int>();
            List<string> lehetseges_orszagok = new List<string>();
            for (int i = 0; i < VB.Count; i++)
            {
                if (!lehetseges_orszagok.Contains(VB[i].hely))
                {
                    lehetseges_orszagok.Add(VB[i].hely);
                }
            }
            for (int i = 0; i < lehetseges_orszagok.Count; i++)
            {
                orszagok[lehetseges_orszagok[i]] = 0;
            }
            for (int i = 0; i < VB.Count; i++)
            {
                orszagok[VB[i].hely]++;
            }

            foreach (string kulcs in orszagok.Keys)
            {
                Console.WriteLine($" {kulcs} : {orszagok[kulcs]}");
            }
        }
        #endregion

        #region F65
        private static void f65(List<orszag_helyezese> VB)
        {
            List<string> orszagok = new List<string>();
            for (int i = 0; i < VB.Count; i++)
            {
                if (!orszagok.Contains(VB[i].ország))
                {
                    orszagok.Add(VB[i].ország);
                }
            }
            foreach (string orszag in orszagok)
            {
                Console.WriteLine($" {orszag}");
            }
        }
        #endregion

        #region F66
        private static void f66(List<orszag_helyezese> VB)
        {
            Dictionary<int, int> evszam = new Dictionary<int, int>();
            List<int> lehetseges_evszam = new List<int>();
            for (int i = 0; i < VB.Count; i++)
            {
                if (!lehetseges_evszam.Contains(VB[i].év))
                {
                    lehetseges_evszam.Add(VB[i].év);
                }
            }
            for (int i = 0; i < lehetseges_evszam.Count; i++)
            {
                evszam[lehetseges_evszam[i]] = 0;
            }
            for (int i = 0; i < VB.Count; i++)
            {
                evszam[VB[i].év]++;
            }

            int max = 0;
            for (int i = 1; i < evszam.Count; i++)
            {
                if (evszam[lehetseges_evszam[i]] > max)
                {
                    max = evszam[lehetseges_evszam[i]];
                }
            }
            for (int i = 0; i < evszam.Count; i++)
            {
                if (evszam[lehetseges_evszam[i]] == max)
                {
                    Console.WriteLine($" {lehetseges_evszam[i]} : {max}");
                }
            }
        }
        #endregion

        #region F67
        private static void f67(List<orszag_helyezese> VB)
        {
            Dictionary<int, int> evtizedek = new Dictionary<int, int>();
            int j;
            for (int i = 1930; i < 2030; i = i + 10)
            {
                evtizedek[i] = 0;
            }
            for (int i = 0; i < VB.Count; i++)
            {
                j = 1940;
                while (j < 2030 && !(VB[i].év < j))
                {
                    j = j + 10;
                }
                evtizedek[j - 10]++;
            }
            int maxi = 1930;
            foreach (int kulcs in evtizedek.Keys)
            {
                if (evtizedek[kulcs] > evtizedek[maxi])
                {
                    maxi = kulcs;
                }
            }
            Console.WriteLine($" {maxi} : {evtizedek[maxi]}");
        }
        #endregion

        #region F68
        private static void f68(List<orszag_helyezese> VB)
        {
            Dictionary<int, int> helyezesek = new Dictionary<int, int>();
            for (int i = 1; i < 41; i++)
            {
                helyezesek[i] = 0;
            }
            for (int i = 0; i < VB.Count; i++)
            {
                helyezesek[VB[i].helyezés]++;
            }
            foreach (int kulcs in helyezesek.Keys)
            {
                if (helyezesek[kulcs] > 0)
                {
                    Console.WriteLine($" {kulcs} : {helyezesek[kulcs]}");
                }
            }
        }
        #endregion

        #region F69
        private static void f69(List<orszag_helyezese> VB)
        {
            Dictionary<string, int> orszagok = new Dictionary<string, int>();
            List<string> lehetseges_orszagok = new List<string>();
            for (int i = 0; i < VB.Count; i++)
            {
                if (!lehetseges_orszagok.Contains(VB[i].ország))
                {
                    lehetseges_orszagok.Add(VB[i].ország);
                }
            }
            for (int i = 0; i < lehetseges_orszagok.Count; i++)
            {
                orszagok[lehetseges_orszagok[i]] = 0;
            }
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].helyezés == 1)
                {
                    orszagok[VB[i].ország] += 6;
                }
                if (VB[i].helyezés == 2)
                {
                    orszagok[VB[i].ország] += 5;
                }
                if (VB[i].helyezés == 3)
                {
                    orszagok[VB[i].ország] += 4;
                }
                if (VB[i].helyezés == 4)
                {
                    orszagok[VB[i].ország] += 3;
                }
                if (VB[i].helyezés == 5)
                {
                    orszagok[VB[i].ország] += 2;
                }
                if (VB[i].helyezés == 6)
                {
                    orszagok[VB[i].ország] += 1;
                }
            }
            foreach (string kulcs in orszagok.Keys)
            {
                Console.WriteLine($" {kulcs} : {orszagok[kulcs]}");
            }
        }
        #endregion

        #region F70
        private static void f70(List<orszag_helyezese> VB)
        {
            Dictionary<string, int> orszagok = new Dictionary<string, int>();
            List<string> lehetseges_orszagok = new List<string>();
            for (int i = 0; i < VB.Count; i++)
            {
                if (!lehetseges_orszagok.Contains(VB[i].ország))
                {
                    lehetseges_orszagok.Add(VB[i].ország);
                }
            }
            for (int i = 0; i < lehetseges_orszagok.Count; i++)
            {
                orszagok[lehetseges_orszagok[i]] = 0;
            }
            for (int i = 0; i < VB.Count; i++)
            {
                if (VB[i].helyezés == 1)
                {
                    orszagok[VB[i].ország] += 6;
                }
                if (VB[i].helyezés == 2)
                {
                    orszagok[VB[i].ország] += 5;
                }
                if (VB[i].helyezés == 3)
                {
                    orszagok[VB[i].ország] += 4;
                }
                if (VB[i].helyezés == 4)
                {
                    orszagok[VB[i].ország] += 3;
                }
                if (VB[i].helyezés == 5)
                {
                    orszagok[VB[i].ország] += 2;
                }
                if (VB[i].helyezés == 6)
                {
                    orszagok[VB[i].ország] += 1;
                }
            }
            int max = 0;
            for (int i = 1; i < orszagok.Count; i++)
            {
                if (orszagok[lehetseges_orszagok[i]] > max)
                {
                    max = orszagok[lehetseges_orszagok[i]];
                }
            }
            for (int i = 0; i < orszagok.Count; i++)
            {
                if (orszagok[lehetseges_orszagok[i]] == max)
                {
                    Console.WriteLine($" {lehetseges_orszagok[i]} : {max}");
                }
            }

        }
        #endregion


        static void Main(string[] args)
        {

            #region Beolvasas
            string[] bemenet = File.ReadAllLines("input.txt");
            List<orszag_helyezese> VB = new List<orszag_helyezese>();
            for (int i = 0; i < bemenet.Length; i++)
            {
                string[] tömb = bemenet[i].Split('	');
                orszag_helyezese a = new orszag_helyezese();
                a.ország = tömb[1];
                a.helyezés = int.Parse(tömb[2]);
                a.év = int.Parse(tömb[3]);
                a.hely = tömb[4];
                VB.Add(a);
            }
            #endregion


            #region f1_5
            Console.WriteLine(" 1. Írja ki Magyarország által elért helyezéseket. A kiírásban jelenjen meg a vb éve és helyszíne is!");
            {
                f1_5(VB, "Magyarország");
            }

            Console.WriteLine(" 2. Írja ki Anglia által elért helyezéseket. A kiírásban jelenjen meg a vb éve és helyszíne is!");
            {
                f1_5(VB, "Anglia");
            }

            Console.WriteLine(" 3. Írja ki Chile által elért helyezéseket. A kiírásban jelenjen meg a vb éve és helyszíne is!");
            {
                f1_5(VB, "Chile");
            }

            Console.WriteLine(" 4. Írja ki Peru által elért helyezéseket. A kiírásban jelenjen meg a vb éve és helyszíne is!");
            {
                f1_5(VB, "Peru");
            }

            Console.WriteLine(" 5. Írja ki Mongólia által elért helyezéseket. A kiírásban jelenjen meg a vb éve és helyszíne is!");
            {
                f1_5(VB, "Mongólia");
            }
            #endregion

            #region f6
            Console.WriteLine(" 6. A program olvasson be egy csapat nevet és írja ki a csapat álta elért helyezéseket. A kiírásban jelenjen meg a vb éve és helyszíne is!");
            {
                f6(VB);
            }
            #endregion

            #region f7_12
            Console.WriteLine(" 7. A program írja ki, hogy az '30-as években kik lettek a világbajnokok! Az ország neve mellett szerepeljen az évszám is!");
            {
                f7_12(VB, 1930);
            }

            Console.WriteLine(" 8. A program írja ki, hogy az '40-as években kik lettek a világbajnokok! Az ország neve mellett szerepeljen az évszám is!");
            {
                f7_12(VB, 1940);
            }

            Console.WriteLine(" 9. A program írja ki, hogy az '50-as években kik lettek a világbajnokok! Az ország neve mellett szerepeljen az évszám is!");
            {
                f7_12(VB, 1950);
            }

            Console.WriteLine(" 10. A program írja ki, hogy az '60-as években kik lettek a világbajnokok! Az ország neve mellett szerepeljen az évszám is!");
            {
                f7_12(VB, 1960);
            }

            Console.WriteLine(" 11. A program írja ki, hogy az '70-as években kik lettek a világbajnokok! Az ország neve mellett szerepeljen az évszám is!");
            {
                f7_12(VB, 1970);
            }

            Console.WriteLine(" 12. A program írja ki, hogy az '80-as években kik lettek a világbajnokok! Az ország neve mellett szerepeljen az évszám is!");
            {
                f7_12(VB, 1980);
            }
            #endregion

            #region f13_17
            Console.Write(" 13. Írja ki Magyarország hányszor jutott ki a vb-re a fájl által tartalmazott időszakban!");
            {
                f13_17(VB, "Magyarország");
            }

            Console.Write(" 14. Írja ki Anglia hányszor jutott ki a vb-re a fájl által tartalmazott időszakban!");
            {
                f13_17(VB, "Anglia");
            }
            
            Console.Write(" 15. Írja ki Chile hányszor jutott ki a vb-re a fájl által tartalmazott időszakban!");
            {
                f13_17(VB, "Chile");
            }
            
            Console.Write(" 16. Írja ki Peru hányszor jutott ki a vb-re a fájl által tartalmazott időszakban!");
            {
                f13_17(VB, "Peru");
            }
            
            Console.Write(" 17. Írja ki Mongólia hányszor jutott ki a vb-re a fájl által tartalmazott időszakban!");
            {
                f13_17(VB, "Mongólia");
            }
            #endregion

            #region f18
            Console.WriteLine(" 18. A program olvasson be egy csapat nevet és írja ki, a csapat hányszor jutott ki a vb-re a fájl által tartalmazott időszakban!");
            {
                f18(VB);
            }
            #endregion

            #region f19_23
            Console.WriteLine(" 19. Melyik csapat nyert 1930-ban?");
            {
                f19_23(VB, 1930);
            }
            
            Console.WriteLine(" 20. Melyik csapat nyert 1940-ban?");
            {
                f19_23(VB, 1940);
            }
            
            Console.WriteLine(" 21. Melyik csapat nyert 1950-ban?");
            {
                f19_23(VB, 1950);
            }
            
            Console.WriteLine(" 22. Melyik csapat nyert 1960-ban?");
            {
                f19_23(VB, 1960);
            }
            
            Console.WriteLine(" 23. Melyik csapat nyert 1970-ban?");
            {
                f19_23(VB, 1970);
            }
            #endregion

            #region f24_29
            Console.Write(" 24. Hányszor kapott ki a döntőben Magyarország?");
            {
                f24_29(VB, "Magyarország");
            }
            
            Console.Write(" 25. Hányszor kapott ki a döntőben Mongólia?");
            {
                f24_29(VB, "Mongólia");
            }
            
            Console.Write(" 26. Hányszor kapott ki a döntőben Svájc?");
            {
                f24_29(VB, "Svájc");
            }
            
            Console.Write(" 27. Hányszor kapott ki a döntőben Brazília?");
            {
                f24_29(VB, "Brazília");
            }
           
            Console.Write(" 28. Hányszor kapott ki a döntőben Németország?");
            {
                f24_29(VB, "Németország");
            }
            
            Console.Write(" 29. Hányszor kapott ki a döntőben Argentína?");
            {
                f24_29(VB, "Argentína");
            }
            #endregion

            #region f30
            Console.WriteLine(" 30. A programm olvasson be évszámot és írja ki, hogy melyik csapat nyert az adott évben!");
            {
                f30(VB);
            }
            #endregion

            #region f31
            Console.Write(" 31. Az adatfájl szerint mikor volt a legkorábbi vb?");
            {
                f31(VB);
            }
            #endregion

            #region f32_36
            Console.Write(" 32. Magyarország hányszor nyert vb-t?");
            {
                f32_36(VB, "Magyarorszag");
            }

            Console.Write(" 33. Anglia hányszor nyert vb-t?");
            {
                f32_36(VB, "Anglia");
            }

            Console.Write(" 34. Chile hányszor nyert vb-t?");
            {
                f32_36(VB, "Chile");
            }

            Console.Write(" 35. Peru hányszor nyert vb-t?");
            {
                f32_36(VB, "Peru");
            }

            Console.Write(" 36. Mongólia hányszor nyert vb-t?");
            {
                f32_36(VB, "Mongólia");
            }
            #endregion

            #region f37_41
            Console.Write(" 37. Írd ki Magyarország vb-n elért legjobb helyezését!");
            {
                f37_41(VB, "Magyarország");
            }

            Console.Write(" 38. Írd ki Anglia vb-n elért legjobb helyezését!");
            {
                f37_41(VB, "Anglia");
            }

            Console.Write(" 39. Írd ki Chile vb-n elért legjobb helyezését!");
            {
                f37_41(VB, "Chile");
            }

            Console.Write(" 40. Írd ki Peru vb-n elért legjobb helyezését!");
            {
                f37_41(VB, "Peru");
            }

            Console.Write(" 41. Írd ki Mongólia vb-n elért legjobb helyezését!");
            {
                f37_41(VB, "Mongólia");
            }
            #endregion

            #region f42
            Console.WriteLine(" 42. A program olvasson be egy csapat nevet és írja ki, a csapat vb-n elért legjobb helyezését!");
            {
                f42(VB);
            }
            #endregion

            #region f43
            Console.WriteLine(" 43. A program olvasson be egy csapat nevet és írja ki, a csapat hányszor nyert vb-t!");
            {
                f43(VB);
            }
            #endregion

            #region f44_48
            Console.WriteLine(" 44. Melyik csapatok nyertek az Angiában rendezett vb-ken? A csapatok neve mellett az évszámot is írja ki!");
            {
                f44_48(VB, "Anglia");
            }

            Console.WriteLine(" 45. Melyik csapatok nyertek az Magyarországon rendezett vb-ken? A csapatok neve mellett az évszámot is írja ki!");
            {
                f44_48(VB, "Magyarország");
            }

            Console.WriteLine(" 46. Melyik csapatok nyertek az Németországban rendezett vb-ken? A csapatok neve mellett az évszámot is írja ki!");
            {
                f44_48(VB, "Németország");
            }

            Console.WriteLine(" 47. Melyik csapatok nyertek az Brazíliában rendezett vb-ken? A csapatok neve mellett az évszámot is írja ki!");
            {
                f44_48(VB, "Brazília");
            }

            Console.WriteLine(" 48. Melyik csapatok nyertek az Egyesült Államok rendezett vb-ken? A csapatok neve mellett az évszámot is írja ki!");
            {
                f44_48(VB, "Egyesült Államok");
            }
            #endregion

            #region f49
            Console.WriteLine(" 49. A program olvasson be egy ország nevet és írja ki, melyik csapatok nyertek az adott helyszínen! A csapatok neve mellett az évszámot is írja ki!");
            {
                f49(VB);
            }
            #endregion

            #region f50_52
            Console.WriteLine(" 50. Melyik csapat nyerte a vb-t, amikor Magyarország dobogós helyzést ért el? A győzetes csapatok neve mellett az évszámot is írja ki!");
            {
                f50_52(VB, "Magyarország");
            }

            Console.WriteLine(" 51. Melyik csapat nyerte a vb-t, amikor Brazília dobogós helyzést ért el? A győzetes csapatok neve mellett az évszámot is írja ki!");
            {
                f50_52(VB, "Brazília");
            }

            Console.WriteLine(" 52. Melyik csapat nyerte a vb-t, amikor Argentína dobogós helyzést ért el? A győzetes csapatok neve mellett az évszámot is írja ki!");
            {
                f50_52(VB, "Argentína");
            }
            #endregion

            #region f53_56
            Console.WriteLine(" 53. Kikkel játszott döntőt Magyarország? Az ellenfél csapat neve mellett az évszámot is írja ki!");
            {
                f53_56(VB, "Magyarország");
            }

            Console.WriteLine(" 54. Kikkel játszott döntőt Mongólia? Az ellenfél csapat neve mellett az évszámot is írja ki!");
            {
                f53_56(VB, "Mongólia");
            }

            Console.WriteLine(" 55. Kikkel játszott döntőt Svájc? Az ellenfél csapat neve mellett az évszámot is írja ki!");
            {
                f53_56(VB, "Svájc");
            }

            Console.WriteLine(" 56. Kikkel játszott döntőt Brazília? Az ellenfél csapat neve mellett az évszámot is írja ki!");
            {
                f53_56(VB, "Brazília");
            }
            #endregion

            #region f57
            Console.WriteLine(" 57. A program olvasson be egy ország nevet és írja ki, kikkel játszott döntőt az illető csapat? Az ellenfél csapat neve mellett az évszámot is írja ki!");
            {
                f57(VB);
            }
            #endregion

            #region f58
            Console.WriteLine(" 58. Mely csapat nyert többször is vb-t?");
            {
                f58(VB);
            }
            #endregion

            #region f59
            Console.WriteLine(" 59. Mely országban rendeztek többször is vb-t?");
            {
                f59(VB);
            }
            #endregion

            #region f60
            Console.WriteLine(" 60. Mely csapat(ok) nyert(ek) a legtöbbször vb-t? A csapat neve mellett a vb gyözelmmek számát is írja ki!");
            {
                f60(VB);
            }
            #endregion

            #region f61
            Console.WriteLine(" 61. Mely ország(ok) rendezett/rendeztek legtöbbször vb-t? A csapat neve mellett a vb-k számát is írja ki!");
            {
                f61(VB);
            }
            #endregion

            #region f62
            Console.WriteLine(" 62. Mely csapat(ok) kapott ki a legtöbbször a döntőben? A csapat neve mellett a vereségek számát is írja ki!");
            {
                f62(VB);
            }
            #endregion

            #region f63
            Console.WriteLine(" 63. Mely ország hányszor szerepel az input fájlban?");
            {
                f63(VB);
            }
            #endregion

            #region f64
            Console.WriteLine(" 64. Add meg a különböző helyszíneket, ahol világbajnokság zajlott!");
            {
                f64(VB);
            }
            #endregion

            #region f65
            Console.WriteLine(" 65. Add meg a különböző országokat, akik az input fájl szerint mérkőzéseket játszottak!");
            {
                f65(VB);
            }
            #endregion

            #region f66
            Console.WriteLine(" 66. Melyik évből származik a legtöbb adat az adatok között, a legelső évszámtól napjainkig?");
            {
                f66(VB);
            }
            #endregion

            #region f67
            Console.WriteLine(" 67. Melyik évtizedből származik a legtöbb adat az adatok között, a 30-as évektől napjainkig? (30-as évek, 40-es évek, stb.)");
            {
                f67(VB);
            }
            #endregion

            #region f68
            Console.WriteLine(" 68. Add meg, hogy a lehetséges helyezések közül melyikhez hány adat kapcsolódik az input fájlban? (1. helyezésből ... db, 2. helyezésből ... db, stb.) A kiírás legyen helyezés szerint növekvő sorrendben!");
            {
                f68(VB);
            }
            #endregion

            #region f69
            Console.WriteLine(" 69. A különböző országok pontversenyeznek is: Az első helyezés 6 pontot ér, a második 5-öt, ... , az hatodik 1 pontot, minden további helyezés pedig 0 pontot ér. Add meg, hogy mely országnak hány pontja van így!");
            {
                f69(VB);
            }
            #endregion

            #region f70
            Console.WriteLine(" 70. Mely országnak van a legtöbb pontja a fent leírt pontversenyben?");
            {
                f70(VB);
            }
            #endregion


            Console.ReadKey();
        }
    }
}
﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
        void Balról_fa(int év, double méret)
        {
            if (év > 0) 
            {
                Előre(méret/2);
                Balra(60);
                Balról_fa(év - 2, 0.5 * méret);
                Jobbra(60);
                Előre(méret/2);
                Balra(50);
                Balról_fa(év - 1, 0.5 * méret);
                Jobbra(50);
                Jobbra(50);
                Balról_fa(év - 1, 0.5 * méret);
                Balra(50);
                Hátra(méret);
            }
        }
        void FELADAT()
		{
            Balról_fa(4, 100);
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _3000E
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] tömb = File.ReadAllLines("PT-3000E.txt");
            int[] számtömb = new int[tömb.Length];
            for (int i = 0; i < tömb.Length; i++)
            {
                számtömb[i] = int.Parse(tömb[i]);
            }


            // 1. Feladat
            {
                Console.WriteLine(" 1. Hány eleme van a sorozatnak?");
                Console.WriteLine($" {számtömb.Length}");
            }
            
            // 2. Feladat
            {
                Console.WriteLine(" 2. Írjuk ki az utolsó 9-cel vagy 3-mal osztható szám indexét!");
                int i = számtömb.Length - 1;
                while (i >= 0 && !(számtömb[i] % 3 == 0 && számtömb[i] % 9 == 0))
                {
                    i--;
                }
                if (i <= 0)
                {
                    Console.WriteLine($" {i}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilyen szám");
                }
            }

            // 3. Feladat
            {
                Console.WriteLine(" 3. Írjuk ki az első 3-mal és 5-tel osztható szám indexét!");
                int i = 0;
                while (i < számtömb.Length && !(számtömb[i] % 3 == 0 && számtömb[i] % 5 == 0))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine($" {i}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilyen szám");
                }
            }

            // 4. Feladat
            {
                
                Console.WriteLine(" 4. Igaz-e, hogy minden szám(-10, 10) nyilt intervallumba esik?");
                int i = 0;
                while (i < számtömb.Length && !(-10 <= számtömb[i] && számtömb[i] <= 10))
                {
                    i++;
                }
                if (i < számtömb[i])
                {
                    Console.WriteLine(" Igaz.");
                }
                else
                {
                    Console.WriteLine(" Nem igaz.");
                }
            }

            // 5. Feladat
            {
                Console.WriteLine(" 5. Mennyi a sorozatban található számok szorzatának kétszerese?");
                int szorzat = 1;
                for (int i = 0; i < 4; i++)
                {
                    szorzat = szorzat * számtömb[i];
                }
                Console.WriteLine($" {szorzat * 2}");
            }

            // 6. Feladat
            {
                Console.WriteLine(" 6. Hány 18-cal és 6-tal osztható szám található a sorozatban ?");
                int db = 0;
                for (int i = 0; i < számtömb.Length; i++)
                {
                    if (számtömb[i] % 18 == 0 && számtömb[i] % 6 == 0)
                    {
                        db++;
                    }
                }
                Console.WriteLine($" {db}");
            }

            // 7. Feladat
            {
                Console.WriteLine(" 7. Írjuk ki a sorozatban található 17-tel vagy 18-cal osztható számok köbét!");
                int j = 0;
                for (int i = 0; i < számtömb.Length; i++)
                {
                    j++;
                    if (számtömb[i] % 18 == 0 || számtömb[i] % 17 == 0)
                    {
                        Console.WriteLine($" {számtömb[i] * számtömb[i] * számtömb[i]}");
                    }
                }
            }

            // 8. Feladat
            {
                Console.WriteLine(" 8. Mennyi a sorozatban található második legkisebb szám?");
                List<int> mini = new List<int>();
                int min = számtömb[0];
                for (int i = 0; i < számtömb.Length; i++)
                {
                    if (számtömb[i] < min)
                    {
                        min = számtömb[i];
                        mini.Add(számtömb[i]);
                    }
                }
                Console.WriteLine($" {mini[mini.Count - 2]}");
            }

            // 9. Feladat
            {
                Console.WriteLine(" 9. Van-e a sorozatban négyzetszám?");
                bool negyzet_e(int szam)
                {
                    for (int j = 0; j < szam; j++)
                    {
                        if (j * j == szam)
                        {
                            return true;
                        }
                    }
                    return false;
                }
                int i = 0;
                while (i < számtömb.Length && !(negyzet_e(számtömb[i])))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine(" Van");
                }
                else
                {
                    Console.WriteLine(" Nincs");
                }
            }

            // 10. Feladat
            {
                Console.WriteLine(" 10. Van-e a sorozatban olyan negatív szám, amelynek az összes szomszédja nulla?");
                int i = 2;
                while (i < számtömb.Length && !(számtömb[i - 1] < 0 && számtömb[i] == 0 && számtömb[i - 2] == 0))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine(" Van");
                }
                else
                {
                    Console.WriteLine(" Nincs");
                }
            }


            Console.ReadKey();
        }
    }
}

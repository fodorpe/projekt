﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Egymást_követő_elemek_keresése
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] tömb = File.ReadAllLines("input.txt");

            int[] számtömb = new int[tömb.Length];

            for (int i = 0; i < tömb.Length; i++)
            {
                számtömb[i] = int.Parse(tömb[i]);
            }


            // 1. Feladat
            {
                Console.WriteLine(" 1.Van-e két olyan egymást követő számpár a sorozatban, amelyek mindegyike 17-tel osztható?");
                int i = 1;
                while (i < számtömb[i] && számtömb[i - 1] % 17 != 0 && számtömb[i] % 17 != 0)
                {
                    i++;
                }
                if (i < számtömb.Length) 
                {
                    Console.WriteLine(" Van");
                }
                else
                {
                    Console.WriteLine(" Nincs");
                }
            }

            // 2. Feladat
            {
                Console.WriteLine(" 2. Add meg az első olyan számot, amelyet egy nála pontosan 1-gyel nagyobb szám követ! Ha nincs ilyen, írd ki, hogy nincs ilyen szám!");
                int i = 1; 
                while (i < számtömb.Length && !(számtömb[i] + 1 == számtömb[i+1]))
                {
                    i++;
                }
                if (i < számtömb.Length) 
                {
                    Console.WriteLine($" {számtömb[i]}");
                }
                else
                {
                    Console.WriteLine(" nincs ilyen szám");
                }
            }

            // 3.Feladat
            {
                Console.WriteLine(" 3. Van-e a sorozatban három egymást követő negatív szám?");
                int i = 2;
                while (i < számtömb.Length && !(számtömb[i - 2] + 1 == számtömb[i - 1]&& számtömb[i - 1] + 1 == számtömb[i]&& számtömb[i] < 0))
                {
                    i++;
                }
                if (i < számtömb.Length) 
                {
                    Console.WriteLine(" Van.");
                }
                else
                {
                    Console.WriteLine(" Nincs.");
                }
            }

            // 4. Feladat
            {
                Console.WriteLine(" 4. Add meg az első olyan számot, amely osztója a következő számnak!");
                int i = 0;
                while (i < számtömb.Length && !(számtömb[i + 1] % számtömb[i] == 0))
                {
                    i++;
                }
                if (i < számtömb.Length) 
                {
                    Console.WriteLine($" {számtömb[i]}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilzen szám");
                }
            }

            /// 5. Feladat
            {
                Console.WriteLine(" 5. Van-e három olyan egymást követő szám a sorozatban, hogy a két szélső átlagától a középső legfeljebb 50-nel tér el?");
                int i = 2;
                while (i < számtömb.Length && !(számtömb[i - 1] - (számtömb[i - 2] + számtömb[i] / 2) < 51)) 
                {
                    i++;
                }
                if (i<számtömb.Length)
                {
                    Console.WriteLine(" Van");
                }
                else
                {
                    Console.WriteLine(" Nincs");
                }
            }

            // 6. Feladat
            {
                Console.WriteLine(" 6. Add meg az utolsó olyan számot, amely osztható az előtte lévő számmal!");
                int i = számtömb.Length - 1;
                while (i<számtömb.Length && !(számtömb[i] % számtömb[i-1] == 0))
                {
                    i--;
                }
                if (i >= 0)
                {
                    Console.WriteLine($" {számtömb[i]}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilzen szám");
                }
            }

            // 7. Feladat
            {
                Console.WriteLine(" 7. Add meg az első olyan szám indexét, amely pontosan kétszerakkora, mint az előző szám!");
                int i = 1;
                while (i < számtömb.Length && !(számtömb[i - 1] * 2 == számtömb[i]))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine($" Van ilyen szám: {i}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilyen szám");
                }
            }

            // 8. Feladat
            {
                Console.WriteLine(" 8. Add meg az utolsó olyan szám indexét, amely az előtte lévő két szám összege!");
                int i = számtömb.Length - 1;
                while (i < 2 && !(számtömb[i - 2] + számtömb[i - 1] == számtömb[i])) 
                {
                    i--;
                }
                if (i >= 2) 
                {
                    Console.WriteLine($" {i}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilyen szám");
                }
            }
            
            // 9. Feladat
            {
                Console.WriteLine(" 9. Add meg az utolsó olyan számot, amely a saját ellentettje után van! Ha nincs ilyen, írd ki, hogy nincs ilyen szám!");
                int i = számtömb.Length - 1;
                while (i >= 1 && !(számtömb[i] * -1 == számtömb[i - 1]))
                {
                    i--;
                }
                if (i <= 1) 
                {
                    Console.WriteLine($" {számtömb[i]}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilyen szám");
                }
            }
            
            // 10. Feladat
            {
                Console.WriteLine(" 10. Add meg az utolsó olyan számot, amely három 5-tel osztható számot követ de maga is 10-zel osztható!");
                int i = számtömb.Length - 1;
                while (i >= 0 && !(számtömb[i - 3] % 5 == 0 && számtömb[i - 2] % 5 == 0 && számtömb[i - 1] % 5 == 0 && számtömb[i] % 10 == 0)) 
                {
                    i--;
                }
                if (i >= 0)
                {
                    Console.WriteLine($" {számtömb[i]}");
                }
                else
                {
                    Console.WriteLine("Nincs ilyen szám");
                }
            }

            // 11. Feladat
            {
                Console.WriteLine(" 11. Add meg az első olyan szám indexét, amely az előtte lévő két szám szorzata!");
                int i = 2;
                while (i < számtömb.Length && !(számtömb[i - 2] * számtömb[i - 1] == számtömb[i])) 
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine($" {i}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilyen szám");
                }
            }

            // 12. Feladat
            {
                Console.WriteLine(" 12. Van-e a sorozatban 5 olyan egymást követő szám, amelyek mindegyike nagyobb az előzőnél?");
                int i = 0;
                while (i < számtömb.Length - 5)
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine(" Van");
                }
                else
                {
                    Console.WriteLine(" Nincs");
                }
            }

            // 13. Feladat
            {
                Console.WriteLine(" 13. Add meg azon szám indexét, amely előáll a két szomszédja átlagaként!");
                int i = 1;
                while (i < számtömb.Length && !(számtömb[i - 1] + számtömb[i + 1] / 2 == számtömb[i])) 
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine($" {i}");
                }
                else
                {
                    Console.WriteLine("Nincs ilyen szám");
                }
            }

            // 14. Feladat
            {
                Console.WriteLine(" 14. Add meg az első olyan szám indexét, ami kisebb mindkét szomszédjánál!");
                int i = 1;
                while (i < számtömb.Length && !(számtömb[i - 1] > számtömb[i]) && !(számtömb[i + 1] > számtömb[i])) 
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine($" {i}");
                }
                else
                {
                    Console.WriteLine("Nincs ilyen szám");
                }
            }

            // 15. Feladat
            {
                Console.WriteLine(" 15. Van-e 5 db olyan egymást követő szám, amelyek összege 15-tel osztható?");
                int i = 4;
                while (i < számtömb.Length && !((számtömb[i - 4] + számtömb[i - 3] + számtömb[i - 2] + számtömb[i - 1] + számtömb[i]) % 15 == 0))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine(" Van");
                }
                else
                {
                    Console.WriteLine("Nincs");
                }
            }


            Console.ReadKey();
        }
    }
}

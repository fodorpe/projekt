﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mester_kivalogatas_5
{
    class Program
    {
        static void Main(string[] args)
        {

            // Beolvaás

            string sor = Console.ReadLine();
            string[] tömb = sor.Split(' ');

            int N = int.Parse(tömb[0]);
            int K = int.Parse(tömb[1]);

            int[] F = new int[N];
            for (int i = 0; i < N; i++)
            {
                F[i] = int.Parse(Console.ReadLine());
            }


            // Feldolgozás

            List<int> sorszam = new List<int>();
            int db = 0;
            for (int i = 0; i < N; i++)
            {
                if (K < F[i])
                {
                    sorszam.Add(i + 1);
                    db++;
                }
            }


            // Kiírás

            Console.Write(db);
            Console.Write(" ");
            for (int i = 0; i < db; i++)
            {
                Console.Write(sorszam[i]);
                Console.Write(" ");
            }
            
        }
    }
}

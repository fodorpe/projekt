﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Különböző_életkorú_dolgozók_száma
{
    class Program
    {
        static bool vane(List<int> l, int n)
        {
            int i = 0;
            while (i < l.Count && l[i] != n)
            {
                i++;
            }
            return i < l.Count ? true : false;
        }
        static void Main(string[] args)
        {

            // beolvasás
            int N = int.Parse(Console.ReadLine());
            int[] É = new int[N];
            List<int> K = new List<int> { };

            for (int i = 0; i < N; i++)
            {
                string sor = Console.ReadLine();
                string[] sortomb = sor.Split(' ');
                É[i] = int.Parse(sortomb[0]);

                // feldolgozás
                if (vane(K, É[i]) != true)
                {
                    K.Add(É[i]);
                }
            }

            // kiírás
            Console.WriteLine(K.Count);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mester_Nyersanyagköltség
{
    class Program
    {
        static void Main(string[] args)
        {
            // Beolvasás

            int N = int.Parse(Console.ReadLine());

            List<int> Á = new List<int>(N);

            for (int i = 0; i < N; i++)
            {
                string ar = Console.ReadLine();

                Á.Add(int.Parse(ar));
            }

            int K = int.Parse(Console.ReadLine());

            int össz = 0;

            for (int i = 0; i < K; i++)
            {
                string anyag1 = Console.ReadLine();

                string[] anyag2 = anyag1.Split(' ');

                össz += Á[int.Parse(anyag2[0]) - 1] * int.Parse(anyag2[1]);
            }

            Console.WriteLine(össz);
        }
    }
}

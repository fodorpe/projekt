﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Világcsúcs_mentes_év
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int[] T = new int[N];
            for (int i = 0; i < N; i++)
            {
                string sor = Console.ReadLine();
                string[] sortomb = sor.Split(' ');
                T[i] = int.Parse(sortomb[0]);
            }


            int k = T.Length - 1;
            while (k > 0 && T[k] - T[k - 1] <= 1)
            {
                k--;
            }


            Console.WriteLine(T[k] - 1);
        }
    }
}

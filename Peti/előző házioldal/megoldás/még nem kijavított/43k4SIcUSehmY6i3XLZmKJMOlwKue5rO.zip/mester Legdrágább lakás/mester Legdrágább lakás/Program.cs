﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mester_Legdrágább_lakás
{
    class Program
    {
        static void Main(string[] args)
        {
            // Beolvasás

            int N = int.Parse(Console.ReadLine());
            int[] Á = new int[N];
            for (int i = 0; i < N; i++)
            {
                string sor = Console.ReadLine();
                string[] tömb = sor.Split(' ');
                Á[i] = int.Parse(tömb[1]);
            }

            // Feldolgozás

            int max = 0;
            for (int i = 0; i < N; i++)
            {
                if (Á[i] > Á[max])
                {
                    max = i;
                }
            }

            // Kiírás

            Console.WriteLine(max + 1);
        }
    }
}

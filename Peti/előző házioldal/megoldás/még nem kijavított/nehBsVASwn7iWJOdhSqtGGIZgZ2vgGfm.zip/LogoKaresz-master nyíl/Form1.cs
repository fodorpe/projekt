﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
		void Nyíl_fraktál_balra(int év, double meret)
		{
			if (év == 1)
			{
				Előre(meret);
			}
			else if (év > 1)
			{
				Balra(60);
				Nyíl_fraktál_jobbra(év - 1, meret / 3);
				Jobbra(60);
				Nyíl_fraktál_balra(év - 1, meret / 3);
				Jobbra(60);
				Nyíl_fraktál_jobbra(év - 1, meret / 3);
				Balra(60);
			}
		}
		void Nyíl_fraktál_jobbra(int év, double meret)
		{
			if (év == 1)
			{
				Előre(meret);
			}
			else if (év > 1)
			{
				Jobbra(60);
				Nyíl_fraktál_balra(év - 1, meret / 3);
				Balra(60);
				Nyíl_fraktál_jobbra(év - 1, meret / 3);
				Balra(60);
				Nyíl_fraktál_balra(év - 1, meret / 3);
				Jobbra(60);
			}
		}
		void Egész(int év, double meret)
		{
			for (int i = 0; i < 1; i++)
			{
				Nyíl_fraktál_balra(év, meret);
				
			}
		}
		void FELADAT()
		{
			Teleport(közép.X - 100, közép.Y, észak);
			Jobbra(90);

			
			using (new Frissítés(false))
			{
				Egész(7, 2000);
			}
			
		}
	}
}

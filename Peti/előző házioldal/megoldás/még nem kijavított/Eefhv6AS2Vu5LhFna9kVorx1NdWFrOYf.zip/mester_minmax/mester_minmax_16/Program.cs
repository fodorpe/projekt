﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mester_minmax_16
{
    class Program
    {
        static void Main(string[] args)
        {
            
            // Beolvasás

            int N = int.Parse(Console.ReadLine());
            int[] K = new int[N];
            for (int i = 0; i < N; i++)
            {
                string sor = Console.ReadLine();
                string[] tömb = sor.Split(' ');
                K[i] = int.Parse(tömb[0]);
            }

            // Feldolgozás

            int max = 0;
            for (int i = 0; i < N; i++)
            {
                if (K[i] > K[max])
                {
                    max = i;
                }
            }

            // Kiírás

            Console.WriteLine(max + 1);
        }
    }
}

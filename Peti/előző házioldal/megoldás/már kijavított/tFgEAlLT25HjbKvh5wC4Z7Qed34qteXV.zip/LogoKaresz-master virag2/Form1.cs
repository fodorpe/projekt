﻿using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
		void Rombusz_zöld(int meret)
		{
			Előre(meret);
			Jobbra(25);
			Előre(meret);
			Jobbra(155);
			Előre(meret);
			Jobbra(25);
			Előre(meret);
			Jobbra(155);

			Jobbra(15);
			Tollat(fel);
			Előre(7);
			Tölt(Color.Green);
			Hátra(7);
			Tollat(le);
			Balra(15);


			Előre(meret);
			Jobbra(25);
			Előre(meret);

			Előre(15);

		}

		void Rombusz_piros_helyre(int meret)
		{
			Előre(meret);
			Jobbra(25);
			Előre(meret);
			Jobbra(155);
			Előre(meret);
			Jobbra(25);
			Előre(meret);
			Jobbra(155);

			Jobbra(18);
			Tollat(fel);
			Előre(7);
			Tölt(Color.Red);
			Hátra(7);
			Tollat(le);
			Balra(18);

			Tollat(fel);
			Hátra(15);
			Hátra(meret * 2);
			Balra(25);
			Hátra(meret * 2);
			Tollat(le);
		}

		void Rombusz_piros(int meret)
		{
			Előre(meret);
			Jobbra(25);
			Előre(meret);
			Jobbra(155);
			Előre(meret);
			Jobbra(25);
			Előre(meret);
			Jobbra(155);

			Jobbra(15);
			Tollat(fel);
			Előre(7);
			Tölt(Color.Red);
			Hátra(7);
			Tollat(le);
			Balra(15);


			Jobbra(30);

		}

		void Virág(int db)
		{
			Tollat(fel);
			Előre(150);
			Tollat(le);


			for (int i = 0; i < db; i++)
			{
				Tollat(fel);
				Előre(25);
				Tollat(le);

				

				Rombusz_zöld(50);

				Rombusz_piros_helyre(25);

				Hátra(25);
				Rombusz_piros(25);
			}
		}
		void FELADAT()
		{
			Virág(12);
		}
	}
}

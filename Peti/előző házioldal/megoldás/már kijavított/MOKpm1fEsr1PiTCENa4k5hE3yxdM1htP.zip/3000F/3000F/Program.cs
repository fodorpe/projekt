﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _3000F
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string[] tömb = File.ReadAllLines("PT-3000F.txt");
            int[] számtömb = new int[tömb.Length];
            for (int i = 0; i < számtömb.Length; i++)
            {
                számtömb[i] = int.Parse(tömb[i]);
            }

            // 1. Feladat
            {
                Console.WriteLine(" 1. Írjuk ki a sorozatban található 17-tel és -17-tel osztható számok harmadát!");
                for (int i = 0; i < számtömb.Length; i++)
                {
                    if (számtömb[i] % 17 == 0)
                    {
                        Console.WriteLine(számtömb[i] / 3);
                    }
                }
            }

            // 2. Feladat 
            {
                Console.WriteLine(" 2. Írjuk ki az utolsó 9-cel vagy 25-tel osztható szám négyzetgyökét!");
                int i = számtömb.Length - 1;
                while (0 <= i && !(számtömb[i] % 9 == 0 || számtömb[i] % 25 == 0))
                {
                    i--;
                }
                if (0 <= i)
                {
                    Console.WriteLine($" {Math.Sqrt(számtömb[i])}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilyen szám");
                }
            }

            // 3. Feladat
            {
                Console.WriteLine(" 3. Írjuk ki az első 3-mal vagy 5-tel osztható szám indexét!");
                int i = 0;
                while (i < számtömb.Length && !(számtömb[i] % 3 == 0 || számtömb[i] % 5 == 0))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine($" {i}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilyen szám");
                }
            }

            // 4. Feladat
            {
                Console.WriteLine(" 4. Igaz-e, hogy minden szám(0, 20) nyilt intervallumba esik?");
                bool igaz_e(int num)
                {
                    if (0 < num && num < 20)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                int i = 0;
                while (i < számtömb.Length && igaz_e(számtömb[i]) == true)
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine(" Nem, nem igaz");
                }
                else
                {
                    Console.WriteLine(" Igen, igaz");
                }
            }

            // 5. Feladat
            {
                Console.WriteLine(" 5. Van-e a sorozatban olyan negatív szám, amelynek az összes szomszédja nulla?");
                int i = 2;
                while (i < számtömb.Length && !(számtömb[i-1] < 0 && számtömb[i] == 0 && számtömb[i - 2] == 0))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine(" Igen, van");
                }
                else
                {
                    Console.WriteLine(" Nem, nincs");
                }
            }

            // 6. Feladat
            {               
                Console.WriteLine(" 6. Hány 18-cal vagy 6-tal osztható szám található a sorozatban?");
                int db = 0;
                for (int i = 0; i < számtömb.Length; i++)
                {
                    if (számtömb[i] % 18 == 0 || számtömb[i] % 6 == 0)
                    {
                        db++;
                    }
                }
                Console.WriteLine($" {db}");
            }

            // 7. Feladat
            {
                Console.WriteLine(" 7. Hány eleme van a sorozatnak?");
                Console.WriteLine($" {számtömb.Length}");
            }

            // 8. Feladat
            {
                Console.WriteLine(" 8. Mennyi a sorozatban található második legnagyobb szám?");
                List<int> maxi = new List<int>();
                int max = számtömb[0];
                for (int i = 0; i < számtömb.Length; i++)
                {
                    if (max < számtömb[i])
                    {
                        max = számtömb[i];
                        maxi.Add(számtömb[i]);
                    }
                }
                Console.WriteLine($" {maxi[maxi.Count - 2]}");
            }

            // 9. Feladat
            {
                Console.WriteLine(" 9. Van-e a sorozatban köbszám?");
                bool köbszam_e(int n)
                {
                    for (int i = 0; i < n; i++)
                    {
                        if (i * i * i == n)
                        {
                            return true;
                        }
                    }

                    return false;
                }
                int k = 0;
                while (k < számtömb.Length && köbszam_e(számtömb[k]))
                {
                    k++;
                }
                if (k < számtömb.Length)
                {
                    Console.WriteLine(" Igen, van");
                }
                else
                {
                    Console.WriteLine(" Nem nincs");
                }
            }

            // 10. Feladat
            {
                Console.WriteLine(" 10. Mennyi a sorozatban található számok szorzatának a fele?");
                int szor = 1;
                for (int i = 0; i < számtömb.Length; i++)
                {
                    szor *= számtömb[i];
                }
                Console.WriteLine($" {szor/2}");
            }


            Console.ReadKey();
        }
    }
}

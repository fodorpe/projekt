﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _3000B
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] tömb = File.ReadAllLines("PT-3000B.txt");
            int[] számtömb = new int[tömb.Length];
            for (int i = 0; i < tömb.Length; i++)
            {
                számtömb[i] = int.Parse(tömb[i]);
            }

            // 1. Feladat
            {
                Console.WriteLine(" 1. Van-e a sorozatban pozitív szám ?");
                int i = 0;
                while (i < számtömb.Length && !(0 <= számtömb.Length))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine(" Van");
                }
                else
                {
                    Console.WriteLine(" Nincs");
                }
            }

            // 2. Feladat
            {
                Console.WriteLine(" 2. Hány eleme van a sorozatnak?");
                Console.WriteLine($" {számtömb.Length}");
            }

            // 3. Feladat
            {
                Console.WriteLine(" 3. Mennyi a sorozatban található legkisebb szám?");
                int legkissebb = számtömb[0];
                for (int i = 1; i < számtömb.Length; i++)
                {
                    if (számtömb[i] < legkissebb)
                    {
                        legkissebb = számtömb[i];
                    }
                }
                Console.WriteLine($" {legkissebb}");
            }

            // 4. Feladat
            {
                Console.WriteLine(" 4. Írjuk ki az első 33-mal osztható szám indexét!");
                int i = 0;
                while (i < számtömb.Length && !(számtömb[i] % 33 == 0))
                {
                    i++;
                }
                Console.WriteLine($" {i}");
            }

            // 5. Feladat
            {
                Console.WriteLine(" 5. Mennyi a sorozatban található számok átlagának fele?");
                int számok_összege = 0;
                int számok = 0;
                for (int i = 0; i < 4; i++)
                {
                    számok_összege += számtömb[i];
                    számok++;
                }
                int összeg = számok_összege / számok / 2;
                Console.WriteLine($" {összeg}");
            }
            // 6. Feladat
            {
                Console.WriteLine(" 6. Igaz-e, hogy minden szám pozitív?");
                int i = 0;
                while (i < számtömb.Length && !(számtömb[i] < 0))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine(" Nem igaz");
                }
                else
                {
                    Console.WriteLine(" Igaz");
                }
            }

            // 7. Feladat
            {
                Console.WriteLine(" 7. Hány páratlan szám található a sorozatban?");
                int db = 0;
                for (int i = 0; i < számtömb.Length; i++)
                {
                    if (számtömb[i] % 2 == 1 || számtömb[i] % 2 == -1)
                    {
                        db++;

                    }
                }
                Console.WriteLine($" {db}");
            }

            // 8. Feladat
            {
                Console.WriteLine(" 8. Van-e a sorozatban olyan negatív szám, amelyet újabb negatív követ?");
                int i = 1;
                while (i < számtömb.Length && !(számtömb[i] < 0 && számtömb[i-1] < 0))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine(" Van");
                }
                else
                {
                    Console.WriteLine(" Nincs");
                }
            }

            // 9. Feladat
            {
                Console.WriteLine(" 9. Írjuk ki az utolsó 19-tel osztható szám indexét!");
                int i = számtömb.Length - 1;
                while (i >= 0 && !(számtömb[i] % 19 == 0))
                {
                    i--;
                }
                if (i >= 0)
                {
                    Console.WriteLine($" {i}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilyen szám");
                }
            }

            // 10. Feladat
            {
                Console.WriteLine(" 10. Írjuk ki a sorozatban található 5-tel osztható számokat!");
                for (int i = 0; i < számtömb.Length; i++)
                {
                    if (számtömb[i] % 5 == 0)
                    {
                        Console.WriteLine($" {számtömb[i]}");
                    }
                }
            }
            

            Console.ReadKey();
        }
    }
}

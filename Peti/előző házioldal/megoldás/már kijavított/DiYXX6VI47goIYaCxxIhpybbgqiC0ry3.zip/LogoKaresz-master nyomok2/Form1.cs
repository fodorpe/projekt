﻿ using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
        void Lábnyom(double méret)
        {
            Előre(méret / 5);
            Ív(180, 10);
            Előre(méret / 5);
            Jobbra(90);
            Előre(méret / 5 * 2);

            Tollat(fel);
            Hátra(méret / 5);
            Jobbra(90);
            Előre(10);
            Tölt(Color.Black);
            Hátra(10);
            Balra(90);
            Előre(méret / 5);

            Balra(90);
            Előre(méret / 5);

            Tollat(le);
            Balra(90);
            Előre(méret / 5 * 2);
            Jobbra(90);
            Előre(méret / 5);
            Ív(180, 10);
            Előre(méret / 5);
            Jobbra(90);

            Odatölt(50, 90, Color.Black);
        }
        void Odatölt(double méret, double fok, Color szín)
        {
            Előre(méret / 5);
            Jobbra(fok);
            Tollat(fel);
            Előre(10);
            Tölt(Color.Black);
            Hátra(10);
            Tollat(le);
            Jobbra(fok);
            Előre(méret / 5);
            Balra(fok);
        }
        void Helyedre(double fok)
        {
            Tollat(fel);
            Jobbra(fok);
            Előre(50);
            Jobbra(fok);
            Előre(20);
            Balra(fok + 20);
            Tollat(le);
            Balra(fok / 2);
        }
        void Lábnyompár()
        {
            Lábnyom(50);
            Helyedre(90);
            Jobbra(225);
            Lábnyom(50);
            Helyedre_második();
        }
        void Lábnyomok(int db)
        {
            for (int i = 0; i < db; i++)
            {
                Lábnyompár();
            }
        }
        void Helyedre_második()
        {
            Tollat(fel);
            Balra(40);
            Előre(70);
            Balra(90);
            Előre(60);
            Tollat(le);
            Balra(120);
        }

        void FELADAT()
        {
            
            Tollat(fel);

            Előre(150);
            Balra(90);
            Előre(300);
            Balra(30);

            Tollat(le);

            Lábnyomok(5);


        }
    }
}

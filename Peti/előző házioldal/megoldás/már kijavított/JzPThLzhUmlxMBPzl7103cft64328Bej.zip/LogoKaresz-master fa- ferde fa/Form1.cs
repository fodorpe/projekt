﻿using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
        void fa(int mélység, double méret)
        {
            if (mélység > 0)
            {
                Előre(méret);
                Balra(30);
                fa(mélység - 1, 0.6 * méret);
                Jobbra(90);
                fa(mélység - 1, 0.6 * méret);
                Balra(60);
                Hátra(méret);
            }
        }

        void FELADAT()
        {
            fa(10, 100);
        }
    }
}

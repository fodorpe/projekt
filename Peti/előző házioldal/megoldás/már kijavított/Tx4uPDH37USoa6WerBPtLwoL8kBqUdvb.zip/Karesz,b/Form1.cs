﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Karesz
{
    public partial class Form1 : Form
    {
        void Piros_négyzet()
        {
            Lépj();
            Lépj();
            for (int i = 0; i < 1; i++)
            {
                Tegyél_le_egy_kavicsot(piros);
                Lépj();
            }
            Tegyél_le_egy_kavicsot(piros);
            Fordulj(jobbra);
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot(piros);
                }
                Fordulj(jobbra);
            }
            Lépj();
            Fordulj(jobbra);
            Lépj();
            Tegyél_le_egy_kavicsot(zöld);
            Fordulj(jobbra);
            Lépj();
            Fordulj(jobbra);
            Lépj();
            Fordulj(jobbra);

            Lépj();
            Lépj();
        }
        void Zöld_négyzet()
        {
            Lépj();
            Lépj();
            for (int i = 0; i < 1; i++)
            {
                Tegyél_le_egy_kavicsot(zöld);
                Lépj();
            }
            Tegyél_le_egy_kavicsot(zöld);
            Fordulj(jobbra);
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot(zöld);
                }
                Fordulj(jobbra);
            }
            Lépj();
            Fordulj(jobbra);
            Lépj();
            Tegyél_le_egy_kavicsot(piros);
            Fordulj(jobbra);
            Lépj();
            Fordulj(jobbra);
            Lépj();
            Fordulj(jobbra);

            Lépj();
            Lépj();
        }
        void Piros_és_zöld_négyzet()
        {
            Piros_négyzet();
            Zöld_négyzet();
        }
        void Piros_oszlop()
        {
            for (int i = 0; i < 3; i++)
            {
                Piros_és_zöld_négyzet();
            }
            Piros_négyzet();
            Lépj();
            Fordulj(jobbra);
            for (int i = 0; i < 5; i++)
            {
                Lépj();
            }
            Fordulj(jobbra);
        }
        void Zöld_és_piros_négyzet()
        {
            Zöld_négyzet();
            Piros_négyzet();

        }
        void Zöld_oszlop()
        {
            for (int i = 0; i < 3; i++)
            {
                Zöld_és_piros_négyzet();
            }
            Zöld_négyzet();
            Lépj();
            Fordulj(balra);
            Lépj();
            Fordulj(balra);
        }
        void Piros_és_zöld_oszlop()
        {
            Piros_oszlop();
            Zöld_oszlop();
        }
        void FELADAT()
        {
            for (int i = 0; i < 3; i++)
            {
                Piros_és_zöld_oszlop();
            }
            Piros_oszlop();
        }

    }
}
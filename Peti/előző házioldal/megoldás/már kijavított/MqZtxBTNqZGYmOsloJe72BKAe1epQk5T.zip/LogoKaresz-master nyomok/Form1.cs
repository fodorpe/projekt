﻿using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
        void Nyom(int meret)
        {

            Előre(meret / 5);
            Ív(180, 10);
            Előre(meret / 5);
            Jobbra(90);
            Előre(meret / 5 * 2);

            Tollat(fel);
            Hátra(meret / 5);
            Jobbra(90);
            Előre(10);
            Tölt(Color.Black);
            Hátra(10);
            Balra(90);
            Előre(meret / 5);

            Balra(90);
            Előre(meret / 5);

            Tollat(le);
            Balra(90);
            Előre(meret / 5 * 2);
            Jobbra(90);
            Előre(meret / 5);
            Ív(180, 10);
            Előre(meret / 5);
            Jobbra(90);

            Előre(meret / 5);
            Jobbra(90);
            Tollat(fel);
            Előre(10);
            Tölt(Color.Black);
            Hátra(10);
            Tollat(le);
            Jobbra(90);
            Előre(meret / 5);
            Balra(90);
        }

        void Helyre()
        {
            Tollat(fel);
            Jobbra(90);
            Előre(50);
            Jobbra(90);
            Előre(20);
            Balra(110);
            Tollat(le);
            Balra(45);
        }
        void Nyompár()
        {
            Nyom(50);
            Helyre();
            Jobbra(225);
            Nyom(50);
            Helyre2();
        }
        void Nyomok(int db)
        {
            for (int i = 0; i < db; i++)
            {
                Nyompár();
            }
        }
        void Helyre2()
        {
            Tollat(fel);
            Előre(50);
            Balra(90);
            Előre(90);
            Balra(180);

            Jobbra(90);
            Előre(20);
            Balra(90);
            Jobbra(25);
        }

        void FELADAT()
        {
            Tollat(fel);
            Előre(100);
            Tollat(le);
            Balra(120);

            Nyomok(5);

        }
    }
}

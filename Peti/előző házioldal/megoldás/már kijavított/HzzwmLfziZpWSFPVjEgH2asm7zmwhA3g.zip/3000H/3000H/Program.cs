﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _3000H
{
    class Program
    {
        private static int utso_negyzet(int[] tomb)
        {
            int i = tomb.Length - 1;
            while (i > 0)
            {
                for (int j = 0; j < 20; j++)
                {
                    if (j * j == tomb[i])
                    {
                        return tomb[i];
                    }
                }
                i--;
            }
            return -1;
        }


        private static int elsokob_i(int[] tomb)
        {
            int i = 0;
            while (i < tomb.Length)
            {
                for (int j = 0; j < 20; j++)
                {
                    if (j * j * j == tomb[i])
                    {
                        return i;
                    }
                }
                i++;
            }
            return -1;
        }


        private static int atlag(int[] tomb)
        {
            int i = 0;
            for (int j = 0; j < tomb.Length; j++)
            {
                i = i + tomb[j];
            }
            return i / tomb.Length;
        }


        private static int legatlag(int[] tomb)
        {
            int átlag = atlag(tomb);
            int atlagos_szam = tomb[0];
            int segedegyenuj = 0;
            int segedegyenleglegatlagos = 0;

            for (int j = 1; j < tomb.Length; j++)
            {
                segedegyenuj = tomb[j] - átlag;
                segedegyenleglegatlagos = atlagos_szam - átlag;
                if (segedegyenuj < 0)
                {
                    segedegyenuj = segedegyenuj * -1;
                }
                if (segedegyenleglegatlagos < 0)
                {
                    segedegyenleglegatlagos = segedegyenleglegatlagos * -1;
                }
                if (segedegyenuj < segedegyenleglegatlagos)
                {
                    atlagos_szam = tomb[j];
                }
            }
            return atlagos_szam;
        }


        private static bool negativelott_2null(int[] tomb)
        {
            int i = 2;
            while (i < tomb.Length && !(tomb[i - 2] == 0 && tomb[i - 1] == 0 && tomb[i] < 0))
            {
                i++;
            }
            return i < tomb.Length;
        }


        private static bool interval(int[] tomb)
        {
            int i = 0;
            for (int j = 0; j < tomb.Length; j++)
            {
                if (tomb[j] > 0 && tomb[j] < 100)
                {
                    i++;
                }
            }
            return i == tomb.Length;
        }


        private static bool mono(int[] tomb)
        {
            int d = tomb[1] - tomb[0];
            for (int i = 2; i < tomb.Length; i++)
            {
                if (tomb[i] - d != tomb[i - 1])
                {
                    return false;
                }
            }
            return true;
        }


        private static bool kettohatv(int[] tomb)
        {
            int i = 0;

            for (int j = 0; j < tomb.Length; j++)
            {
                for (int x = 1; x < 20; x++)
                {
                    if (Math.Pow(2, x) == tomb[j])
                    {
                        return true;
                    }
                }
            }
            return false;
        }





        static void Main(string[] args)
        {
            string[] alaptomb = File.ReadAllLines("3000H.txt");
            int[] tomb = new int[alaptomb.Length];
            for (int i = 0; i < alaptomb.Length; i++)
            {
                tomb[i] = int.Parse(alaptomb[i]);
            }


            // 1. Feladat
            Console.WriteLine($" 1. Írjuk ki a sorozatban található utolsó négyzetszámot! {utso_negyzet(tomb)} ");

            // 2. Feladat
            Console.WriteLine($" 2. Írjuk ki  a sorozatban található első köbszám indexét! {elsokob_i(tomb)}");

            // 3. Feladat
            Console.WriteLine($" 3. Mennyi a sorozatban található számok számtani közepe? {atlag(tomb)}");

            // 4. Feladat
            Console.WriteLine($" 4. Mennyi a sorozatban található legátlagosabb szám? (legkevésbé tér el az átlagtól) {legatlag(tomb)}");

            // 5. Feladat
            Console.WriteLine($" 5. Írjuk ki a sorozatban található négyzetszámok négyzetgyökét!");
            for (int i = 0; i < tomb.Length; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    if (j * j == tomb[i])
                    {
                        Console.WriteLine($" {tomb[i] / j}");
                    }
                }
            }

            // 6. Feladat
            Console.WriteLine($" 6. Van-e a sorozatban olyan negatív szám, amelyet két nulla is megelőz? {negativelott_2null(tomb)}");

            // 7. Feladat
            {
                Console.WriteLine($" 7. Hány eleme van a sorozatnak? {tomb.Length}");
            }

            // 8. Feladat
            Console.WriteLine($" 8. Igaz-e, hogy minden szám [0,100] zárt intervallumba esik? {interval(tomb)}");

            // 9. Feladat
            Console.WriteLine($" 9. Igaz-e, hogy a sorozat monoton növő? {mono(tomb)}");

            // 10. Feladat
            Console.WriteLine($" 10. Van-e a sorozatban kettő hatvány? {kettohatv(tomb)}");


            Console.ReadKey();
        }
    }
}

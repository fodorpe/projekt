﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Karesz
{
    public partial class Form1 : Form
    {
        void Óra(int szin)
        {
            Lépj();
            for (int i = 0; i < 2; i++)
            {
                Lépj();
                Fordulj(jobbra);
                Lépj();
                Tegyél_le_egy_kavicsot(szin);
                Fordulj(balra);
            }
            Lépj();
            Tegyél_le_egy_kavicsot(szin);
            for (int i = 0; i < 2; i++)
            {
                Lépj();
                Fordulj(jobbra);
                Lépj();
                Tegyél_le_egy_kavicsot(szin);
                Fordulj(balra);
            }
            Fordulj(balra);
            
            
            
            for (int i = 0; i < 4; i++)
            {
                Lépj();
                Tegyél_le_egy_kavicsot(szin);
            }
            Fordulj(balra);




            Lépj();
            Fordulj(balra);
            Lépj();
            Tegyél_le_egy_kavicsot(szin);
            Fordulj(jobbra);

            Lépj();
            Fordulj(balra);
            Lépj();
            Fordulj(jobbra);

            Lépj();

            for (int i = 0; i < 2; i++)
            {
                Lépj();
                Fordulj(balra);
                Lépj();
                Tegyél_le_egy_kavicsot(szin);
                Fordulj(jobbra);
            }
            Fordulj(jobbra);
            for (int i = 0; i < 4; i++)
            {
                Lépj();
                Tegyél_le_egy_kavicsot(szin);
            }
            Fordulj(jobbra);
            for (int i = 0; i < 5; i++)
            {
                Lépj();
            }
        }
        void Sor()
        {
            Óra(zöld);
            Óra(piros);
            Óra(zöld);
            Óra(piros);
        }
        void Két_Sor()
        {
            Sor();
            Lépj();
            Fordulj(jobbra);
            for (int i = 0; i < 9; i++)
            {
                Lépj();
            }
            Fordulj(jobbra);
            Sor();
            for (int i = 0; i < 2; i++)
            {
                Lépj();
                Fordulj(balra);
            }
        }


        void FELADAT()
        {
            for (int i = 0; i < 2; i++)
            {
                Két_Sor();
            }
        }     
    }
}
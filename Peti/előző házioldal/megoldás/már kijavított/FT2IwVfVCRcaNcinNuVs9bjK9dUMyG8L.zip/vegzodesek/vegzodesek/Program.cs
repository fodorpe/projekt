﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vegzodesek
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 7;
            while (x<500)
            {
                Console.WriteLine(x);
                x += 10;
            }







        }
    }
}

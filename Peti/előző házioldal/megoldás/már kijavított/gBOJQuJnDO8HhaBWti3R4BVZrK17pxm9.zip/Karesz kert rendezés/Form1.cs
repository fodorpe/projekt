﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Karesz
{
    public partial class Form1 : Form
    {
        bool vége = false;
        void Irány_a_jobb_felső_sarok()
        {
            for (int i = 0; i < 2; i++)
            {
                while (!Kilépek_e_a_pályáról())
                {
                    Lépj();
                }
                if (Kilépek_e_a_pályáról())
                {
                    Fordulj(jobbra);
                }
            }
        }

        void FELADAT()
        {
            Irány_a_jobb_felső_sarok();
            while (!vége)
            {
                while (!Kilépek_e_a_pályáról())
                {
                    if (Mi_van_alattam() == sárga)
                    {
                        Lépj();
                        Tegyél_le_egy_kavicsot(zöld);
                        Fordulj_jobbra();
                        Lépj();
                        Tegyél_le_egy_kavicsot(zöld);
                        for (int j = 0; j < 3; j++)
                        {
                            Fordulj_jobbra();
                            Lépj();
                            Tegyél_le_egy_kavicsot(zöld);
                            Lépj();
                            Tegyél_le_egy_kavicsot(zöld);
                        }
                        Fordulj_jobbra();
                        Lépj();
                        Fordulj_balra();
                    }
                    Lépj();
                    if (Mi_van_alattam() == sárga)
                    {
                        Lépj();
                        Tegyél_le_egy_kavicsot(zöld);
                        Fordulj_jobbra();
                        Lépj();
                        Tegyél_le_egy_kavicsot(zöld);
                        for (int j = 0; j < 3; j++)
                        {
                            Fordulj_jobbra();
                            Lépj();
                            Tegyél_le_egy_kavicsot(zöld);
                            Lépj();
                            Tegyél_le_egy_kavicsot(zöld);
                        }
                        Fordulj_jobbra();
                        Lépj();
                        Fordulj_balra();
                    }
                }
                if (Kilépek_e_a_pályáról())
                {
                    Fordulj(jobbra);

                    if (Kilépek_e_a_pályáról())
                    {
                        vége = true;
                    }
                    else { Lépj(); }
                    if (Mi_van_alattam() == sárga)
                    {
                        Lépj();
                        Tegyél_le_egy_kavicsot(zöld);
                        Fordulj_jobbra();
                        Lépj();
                        Tegyél_le_egy_kavicsot(zöld);
                        for (int j = 0; j < 3; j++)
                        {
                            Fordulj_jobbra();
                            Lépj();
                            Tegyél_le_egy_kavicsot(zöld);
                            Lépj();
                            Tegyél_le_egy_kavicsot(zöld);
                        }
                        Fordulj_jobbra();
                        Lépj();
                        Fordulj_balra();
                    }
                    Fordulj_jobbra();
                }
                while (!Kilépek_e_a_pályáról())
                {
                    if (Mi_van_alattam() == sárga)
                    {
                        Lépj();
                        Tegyél_le_egy_kavicsot(zöld);
                        Fordulj_jobbra();
                        Lépj();
                        Tegyél_le_egy_kavicsot(zöld);
                        for (int j = 0; j < 3; j++)
                        {
                            Fordulj_jobbra();
                            Lépj();
                            Tegyél_le_egy_kavicsot(zöld);
                            Lépj();
                            Tegyél_le_egy_kavicsot(zöld);
                        }
                        Fordulj_jobbra();
                        Lépj();
                        Fordulj_balra();
                    }
                    Lépj();
                    if (Mi_van_alattam() == sárga)
                    {
                        Lépj();
                        Tegyél_le_egy_kavicsot(zöld);
                        Fordulj_jobbra();
                        Lépj();
                        Tegyél_le_egy_kavicsot(zöld);
                        for (int j = 0; j < 3; j++)
                        {
                            Fordulj_jobbra();
                            Lépj();
                            Tegyél_le_egy_kavicsot(zöld);
                            Lépj();
                            Tegyél_le_egy_kavicsot(zöld);
                        }
                        Fordulj_jobbra();
                        Lépj();
                        Fordulj_balra();
                    }
                }
                if (Kilépek_e_a_pályáról())
                {
                    Fordulj(balra);

                    if (Kilépek_e_a_pályáról())
                    {
                        vége = true;
                    }
                    else { Lépj(); }
                    if (Mi_van_alattam() == sárga)
                    {
                        Lépj();
                        Tegyél_le_egy_kavicsot(zöld);
                        Fordulj_jobbra();
                        Lépj();
                        Tegyél_le_egy_kavicsot(zöld);
                        for (int j = 0; j < 3; j++)
                        {
                            Fordulj_jobbra();
                            Lépj();
                            Tegyél_le_egy_kavicsot(zöld);
                            Lépj();
                            Tegyél_le_egy_kavicsot(zöld);
                        }
                        Fordulj_jobbra();
                        Lépj();
                        Fordulj_balra();
                    }
                    Fordulj_balra();
                }
            }

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Karesz
{
    public partial class Form1 : Form
    {

        void FELADAT()
        {
            for (int j = 0; j < 2; j++)
            {
                for (int i = 0; i < 10; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                Fordulj_jobbra();
                for (int i = 0; i < 20; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                Fordulj_jobbra();
            }
            for (int i = 0; i < 11; i++)
            {
                Lépj();
            }
            Tegyél_le_egy_kavicsot();
            for (int i = 0; i < 10; i++)
            {
                Lépj();
                Fordulj_jobbra();
                Lépj();
                Tegyél_le_egy_kavicsot();
                Fordulj_balra();
            }
            Fordulj_jobbra();
            Fordulj_jobbra();
            for (int i = 0; i < 10; i++)
            {
                Lépj();
                Fordulj_balra();
                Lépj();
                Tegyél_le_egy_kavicsot();
                Fordulj_jobbra();
            }
            Fordulj_jobbra();
            for (int i = 0; i < 4; i++)
            {
                Lépj();
            }
            Fordulj_balra();
            for (int i = 0; i < 3; i++)
            {
                Lépj();
            }
            for (int j = 0; j < 4; j++)
            {
                for (int i = 0; i < 3; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                Fordulj_jobbra();
            }
            for (int i = 0; i < 8; i++)
            {
                Lépj();
            }
            Fordulj_jobbra();
            for (int i = 0; i < 12; i++)
            {
                Lépj();
            }
            Fordulj_jobbra();
            for (int i = 0; i < 5; i++)
            {
                Lépj();
                Tegyél_le_egy_kavicsot();
            }
            Fordulj_jobbra();
            for (int i = 0; i < 4; i++)
            {
                Lépj();
                Tegyél_le_egy_kavicsot();
            }
            Fordulj_jobbra();
            for (int i = 0; i < 4; i++)
            {
                Lépj();
                Tegyél_le_egy_kavicsot();
            }
            Fordulj_balra();
            for (int i = 0; i < 14; i++)
            {
                Lépj();
            }
            Fordulj_jobbra();
            Lépj();
            Tegyél_le_egy_kavicsot();
            Fordulj_balra();
            Fordulj_balra();
            for (int j = 0; j < 4; j++)
            {
                for (int i = 0; i < 7; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                Fordulj_jobbra();
                for (int i = 0; i < 2; i++)
                {
                    Lépj();
                }
                Tegyél_le_egy_kavicsot();
                Fordulj_jobbra();
                for (int i = 0; i < 7; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                Fordulj_balra();
                for (int i = 0; i < 2; i++)
                {
                    Lépj();
                }
                Tegyél_le_egy_kavicsot();
                Fordulj_balra();
            }
            Vegyél_fel_egy_kavicsot();
            Lépj();
            Fordulj_balra();
            for (int i = 0; i < 2; i++)
            {
                Lépj();
            }
            for (int i = 0; i < 8; i++)
            {
                Lépj();
                Tegyél_le_egy_kavicsot();
                Lépj();
            }
            Fordulj_jobbra();
            for (int i = 0; i < 4; i++)
            {
                Lépj();
            }
            Fordulj_jobbra();
            for (int i = 0; i < 8; i++)
            {
                Lépj();
                Tegyél_le_egy_kavicsot();
                Lépj();
            }
            Fordulj_balra();
            for (int i = 0; i < 3; i++)
            {
                Lépj();
            }

        }     
    }
}
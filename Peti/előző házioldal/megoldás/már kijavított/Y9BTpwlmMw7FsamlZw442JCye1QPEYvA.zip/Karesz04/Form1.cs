﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Karesz
{
    public partial class Form1 : Form
    {

        void FELADAT()
        {
            for (int k = 0; k < 5; k++)
            {
                for (int i = 0; i < 9; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                Fordulj_jobbra();
                for (int i = 0; i < 4; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                for (int j = 0; j < 2; j++)
                {
                    Fordulj_jobbra();
                    for (int i = 0; i < 2; i++)
                    {
                        Lépj();
                        Tegyél_le_egy_kavicsot();
                    }
                }
                Fordulj_balra();
                for (int i = 0; i < 5; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                Fordulj_balra();
                Lépj();
                Tegyél_le_egy_kavicsot();
                Fordulj_balra();
                Lépj();
                for (int i = 0; i < 2; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                for (int i = 0; i < 2; i++)
                {
                    Lépj();
                }
                Fordulj_jobbra();
                Lépj();
                Fordulj_jobbra();
                Lépj();
                for (int i = 0; i < 2; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                for (int i = 0; i < 2; i++)
                {
                    Lépj();
                }
                Tegyél_le_egy_kavicsot();
                Fordulj_balra();
                Lépj();
                Fordulj_balra();
                Lépj();
                for (int i = 0; i < 2; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                for (int i = 0; i < 2; i++)
                {
                    Lépj();
                }
                Fordulj_balra();
                Lépj();
                Fordulj_balra();
                for (int i = 0; i < 5; i++)
                {
                    Lépj();
                }
                for (int i = 0; i < 2; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                Fordulj_jobbra();
                for (int i = 0; i < 4; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                for (int i = 0; i < 2; i++)
                {
                    Fordulj_jobbra();
                }
                for (int i = 0; i < 6; i++)
                {
                    Lépj();
                }
                Fordulj_balra();
            }

        }     
    }
}
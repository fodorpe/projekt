﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oszthatosag
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Kedves felhasználó! Írj be egy pozitív egész számot és megmondom, hogy osztható-e 17-tel");

            int input = int.Parse(Console.ReadLine());
            while(!(input > 0))
            {
                Console.WriteLine("Próbáljuk újra. Pozitív számot írj be!");
                input = int.Parse(Console.ReadLine());
            }
            if(input % 17 ==0)
            {
                Console.WriteLine("A szám osztható 17-tel");
            }
            else
            {
                Console.WriteLine("A szám nem osztható 17-tel");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Kedves felhasználó! Ez egy kő, papír, olló játék!");
            Console.WriteLine("A szabály egyszeű, a kő üti az ollót, az olló a papírt, a papír a követ.");
            Console.WriteLine("Na mit választasz, kő, papír vagy olló?");
  
            string a = Console.ReadLine();
            int c;
            Random d = new Random();
            c = d.Next(1, 4);

            if (c == 1)
            {
                Console.WriteLine("kő");
            }

            if (c == 2)
            {
                Console.WriteLine("papír");
            }

            if (c == 3)
            {
                Console.WriteLine("olló");
            }

            if (a == "kő")
            {
                if (c == 1)
                {
                    Console.WriteLine("Döntetlen");
                }

                if (c == 2)
                {
                    Console.WriteLine("Vesztettél");
                }

                if (c == 3)
                {
                    Console.WriteLine("Nyertél");
                }
            }

            if (a == "papír")
            {
                if (c == 1)
                {
                    Console.WriteLine("Nyertél");
                }

                if (c == 2)
                {
                    Console.WriteLine("Döntetlen");
                }

                if (c == 3)
                {
                    Console.WriteLine("Vesztettél");
                }
            }

            if (a == "olló")
            {
                if (c == 1)
                {
                    Console.WriteLine("Vesztettél");
                }

                if (c == 2)
                {
                    Console.WriteLine("Nyertél");
                }

                if (c == 3)
                {
                    Console.WriteLine("Döntetlen");
                }
            }
        }
    }
}

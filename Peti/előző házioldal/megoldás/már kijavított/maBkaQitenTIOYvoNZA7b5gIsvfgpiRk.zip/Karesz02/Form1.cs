﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Karesz
{
    public partial class Form1 : Form
    {

        void FELADAT()
        {
            for (int k = 0; k < 4; k++)
            {
                for (int i = 0; i < 2; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                }
                for (int i = 0; i < 2; i++)
                {
                    Lépj();
                    Fordulj_jobbra();
                    Lépj();
                    Tegyél_le_egy_kavicsot();
                    Fordulj_balra();
                }
                Fordulj_jobbra();
            }
            Fordulj_balra();
            Lépj();
        }     
    }
}
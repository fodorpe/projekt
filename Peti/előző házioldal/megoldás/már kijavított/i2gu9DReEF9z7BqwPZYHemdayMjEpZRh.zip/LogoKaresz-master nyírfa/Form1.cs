﻿using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{

        void nyírfa(int melyseg, double hossz)
        {
            if (melyseg == 1)
            {
                Előre(hossz);
                Hátra(hossz);
            }
            if (melyseg > 0)
            {
                Előre(hossz / 2);
                Fordulj(30);
                nyírfa(melyseg - 1, hossz / 2);
                Fordulj(-30);
                nyírfa(melyseg - 1, hossz / 2);
                Előre(hossz / 2);
                Fordulj(-30);
                nyírfa(melyseg - 1, hossz / 2);
                Fordulj(30);
                nyírfa(melyseg - 1, hossz / 2);
                Hátra(hossz);
            }
        }

        void FELADAT()
        {
            
           nyírfa(5, 100); 
           
        }
    }
}

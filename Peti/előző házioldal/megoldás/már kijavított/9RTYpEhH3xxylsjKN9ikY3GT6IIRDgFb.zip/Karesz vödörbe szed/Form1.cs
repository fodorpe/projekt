﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Karesz
{
    public partial class Form1 : Form
    {
        void iránybanéz()
        {
            if (Merre_néz() == dél)
            {
                Fordulj_jobbra();
                Fordulj_jobbra();
            }
            if (Merre_néz() == kelet)
            {
                Fordulj_balra();
            }
            if (Merre_néz() == nyugat)
            {
                Fordulj_jobbra();
            }
        }
        void jobbfelsősarok()
        {
            for (int i = 0; i < 2; i++)
            {
                while (!Kilépek_e_a_pályáról())
                {
                    Lépj();
                }
                Fordulj_jobbra();
            }
        }
        void FELADAT()
        {
            iránybanéz();
            jobbfelsősarok();

            bool nem = true;
            int irány = 1;
            int kavicsokszáma = 0;

            while (nem == true)
            {
                while (!Kilépek_e_a_pályáról())
                {
                    if (Van_e_előttem_fal())
                    {
                        nem = false;
                        break;
                    }
                    if (nem == true)
                    {
                        if (Van_e_itt_kavics())
                        {
                            Vegyél_fel_egy_kavicsot();
                            kavicsokszáma++;
                        }
                        Lépj();
                    }
                }
                if (irány == 1)
                {
                    if (Van_e_előttem_fal())
                    {
                        nem = false;
                        break;
                    }
                    Fordulj_jobbra();
                    if (Van_e_itt_kavics())
                    {
                        Vegyél_fel_egy_kavicsot();
                        kavicsokszáma++;
                    }
                    Lépj();
                    Fordulj_jobbra();
                    irány = 0;
                }
                else if (irány == 0)
                {
                    if (Van_e_előttem_fal())
                    {
                        nem = false;
                        break;
                    }
                    Fordulj_balra();
                    if (Van_e_itt_kavics())
                    {
                        Vegyél_fel_egy_kavicsot();
                        kavicsokszáma++;
                    }
                    Lépj();
                    Fordulj_balra();
                    irány = 1;
                }
                if (Van_e_előttem_fal())
                {
                    nem = false;
                    break;
                }
            }
            
            Fordulj_jobbra();
            Fordulj_jobbra();
            while (true)
            {
                while (!Kilépek_e_a_pályáról() && !Van_e_előttem_fal())
                {
                    if (Mi_van_alattam() == fekete)
                    {
                        Vegyél_fel_egy_kavicsot();
                        kavicsokszáma++;
                    }
                    Lépj();
                }
                if (irány == 0)
                {
                    Fordulj_jobbra();
                    if (Mi_van_alattam() == fekete)
                    {
                        Vegyél_fel_egy_kavicsot();
                        kavicsokszáma++;
                    }
                    if (Van_e_előttem_fal())
                    {
                        break;
                    }
                    Lépj();
                    Fordulj_jobbra();
                    irány = 1;
                }
                else if (irány == 1)
                {
                    Fordulj_balra();
                    if (Mi_van_alattam() == fekete)
                    {
                        Vegyél_fel_egy_kavicsot();
                        kavicsokszáma++;
                    }
                    Lépj();
                    Fordulj_balra();
                    irány = 0;
                }
            }

            Fordulj_jobbra();
            while (!Kilépek_e_a_pályáról())
            {
                if (Mi_van_alattam() == fekete)
                {
                    Vegyél_fel_egy_kavicsot();
                    kavicsokszáma++;
                }
                Lépj();
            }
            Fordulj_balra();
            Lépj();
            Fordulj_balra();
            while (!Van_e_előttem_fal())
            {
                if (Mi_van_alattam() == fekete)
                {
                    Vegyél_fel_egy_kavicsot();
                    kavicsokszáma++;
                }
                Lépj();
            }
            Fordulj_balra();
            Lépj();
            Fordulj_jobbra();
            while (!Van_e_előttem_fal())
            {
                if (Mi_van_alattam() == fekete)
                {
                    Vegyél_fel_egy_kavicsot();
                    kavicsokszáma++;
                }
                Lépj();
            }
            Fordulj_balra();
            while (kavicsokszáma > 0)
            {
                Tegyél_le_egy_kavicsot(fekete);
                kavicsokszáma--;
                if (!Van_e_előttem_fal())
                {
                    Lépj();
                }
                else
                {
                    Fordulj_balra();
                    Lépj();
                    Fordulj_balra();
                    while (!Van_e_előttem_fal())
                    {
                        Lépj();
                    }
                    Fordulj_jobbra();
                    Fordulj_jobbra();
                }
            }
        }

    }
}
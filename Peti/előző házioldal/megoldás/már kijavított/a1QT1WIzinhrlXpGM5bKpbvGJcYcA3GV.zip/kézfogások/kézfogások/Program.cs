﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kézfogások
{
    class Program
    {
        static void Main(string[] args)
        {
            int kezfogasok;
            Console.WriteLine("Kedves felhasználó! Hány fős a csoportod?");
            int csoport = int.Parse(Console.ReadLine());
            kezfogasok = (csoport * (csoport - 1)) / 2;
            Console.WriteLine("Ha mindenki kezet fog mindenkivel, akkor " + kezfogasok + " darab kézfogás történik");





        }
    }
}

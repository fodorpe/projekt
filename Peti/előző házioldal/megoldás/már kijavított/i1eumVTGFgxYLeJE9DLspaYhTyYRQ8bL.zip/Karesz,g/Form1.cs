﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Karesz
{
    public partial class Form1 : Form
    {
        void Lépj(int lepesszam)
        {
            for (int i = 0; i < lepesszam; i++)
            {
                Lépj();
            }
        }
        void Hátra_Lépj()
        {
            Fordulj(jobbra);
            Fordulj(jobbra);
            Lépj();
            Fordulj(jobbra);
            Fordulj(jobbra);
        }
        void Kereszt(int szin)
        {
            for (int j = 0; j < 4; j++)
            {
                for (int i = 0; i < 3; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot(szin);
                }
                Fordulj(balra);
                for (int i = 0; i < 3; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot(szin);
                }
                Fordulj(jobbra);
                for (int i = 0; i < 3; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot(szin);
                }
                Fordulj(jobbra);
            }
        }
        void Zöld_oszlop()
        {
            Kereszt(zöld);
            Lépj(10);
            Kereszt(piros);
            Lépj(10);
            Kereszt(zöld);
            Lépj(9);
            Fordulj(jobbra);
            Lépj(13);
            Fordulj_jobbra();
        }
        void Piros_oszlop()
        {
            Kereszt(piros);
            Lépj(10);
            Kereszt(zöld);
            Lépj(10);
            Kereszt(piros);
            Lépj(9);
            Fordulj(balra);
            Lépj(7);
            Fordulj_balra();
        }
        void FELADAT()
        {
            Hátra_Lépj();
            Zöld_oszlop();
            Piros_oszlop();
            Zöld_oszlop();
        }
        
    }
}
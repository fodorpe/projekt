﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _3000I
{
    class Program
    {
        private static int utso_kob(int[] tomb)
        {
            int i = tomb.Length - 1;
            while (i > 0)
            {
                for (int j = 0; j < 20; j++)
                {
                    if (j * j == tomb[i])
                    {
                        return tomb[i];
                    }
                }
                i--;
            }
            return -1;
        }


        private static int diff(int[] tomb)
        {
            int min = tomb[0];
            int max = tomb[0];
            for (int i = 0; i < tomb.Length; i++)
            {
                if (tomb[i] < min)
                {
                    min = tomb[i];
                }
                if (tomb[i] > max)
                {
                    max = tomb[i];
                }
            }
            return max - min;
        }


        private static bool szam_oszt_index(int[] tomb)
        {
            int i = tomb.Length;
            while (i > 0)
            {
                i--;
                for (int j = 0; j < 200; j++)
                {
                    if (i * j == tomb[i])
                    {
                        return true;
                    }
                }
            }
            return false;
        }


        private static bool szamtani_e(int[] tomb)
        {
            int i = 0;
            for (int j = 0; j < tomb.Length; j++)
            {
                if (tomb[i] % 1 == 0)
                {
                    i++;
                }
            }
            return i == tomb.Length;
        }


        private static int elso_negyzet(int[] tomb)
        {
            int i = -1;
            while (i < tomb.Length)
            {
                i++;
                for (int j = 0; j < 20; j++)
                {
                    if (j * j == tomb[i])
                    {
                        return tomb[i] * tomb[i];
                    }
                }
            }
            return -1;
        }


        private static bool prim(int[] tomb)
        {
            int i = -1;
            int seged;
            while (i < tomb.Length)
            {
                i++;
                seged = 0;
                for (int j = 2; j < 30; j++)
                {
                    if (tomb[i] % j != 0)
                    {
                        seged++;
                    }
                }
                if (seged == 27)
                {
                    return true;
                }
            }
            return false;
        }


        private static bool interv(int[] tomb)
        {
            for (int i = 0; i < tomb.Length; i++)
            {
                if (!(tomb[i] >= -50 && tomb[i] <= 50))
                {
                    return false;
                }
            }
            return true;
        }


        private static int átlag(int[] tomb)
        {
            int i = 0;
            for (int j = 0; j < tomb.Length; j++)
            {
                i = i + tomb[j];
            }
            return i / tomb.Length;
        }

        private static int legatlag(int[] tomb)
        {
            int atlag = átlag(tomb);
            int atlagos_szam = tomb[0];
            int segedegyenuj = 0;
            int segedegyenleglegatlagos = 0;

            for (int j = 1; j < tomb.Length; j++)
            {
                segedegyenuj = tomb[j] - atlag;
                segedegyenleglegatlagos = atlagos_szam - atlag;
                if (segedegyenuj < 0)
                {
                    segedegyenuj = segedegyenuj * -1;
                }
                if (segedegyenleglegatlagos < 0)
                {
                    segedegyenleglegatlagos = segedegyenleglegatlagos * -1;
                }
                if (segedegyenuj < segedegyenleglegatlagos)
                {
                    atlagos_szam = tomb[j];
                }
            }
            return atlagos_szam;
        }



        static void Main(string[] args)
        {
            string[] alaptomb = File.ReadAllLines("3000I.txt");
            int[] tomb = new int[alaptomb.Length];
            for (int i = 0; i < alaptomb.Length; i++)
            {
                tomb[i] = int.Parse(alaptomb[i]);
            }


            // 1. Feladat
            Console.WriteLine($" 1. Írjuk ki a sorozatban található utolsó köbszámot! {utso_kob(tomb)}");

            // 2. Feladat
            Console.WriteLine($" 2. Hány eleme van a sorozatnak? {tomb.Length}");

            // 3. Feladat
            Console.WriteLine($" 3. Mennyi a sorozatban található számok közti diferencia összege? {diff(tomb)}");

            // 4. Feladat
            Console.WriteLine($" 4. Van-e a sorozatban olyan szám, amely osztható az indexével? {szam_oszt_index(tomb)}");

            // 5. Feladat
            Console.WriteLine($" 5. Igaz-e, hogy a sorozat egy számtani sorozat? {szamtani_e(tomb)}");

            // 6. Feladat
            Console.WriteLine($" 6. Írjuk ki a sorozatban található első négyzetszám négyzetét! {elso_negyzet(tomb)}");

            // 7. Feladat
            Console.WriteLine($" 7. Van-e a sorozatban prímszám? {prim(tomb)}");

            // 8. Feladat
            Console.WriteLine($" 8. Igaz-e, hogy minden szám (-50,50) nyílt intervallumba esik? {interv(tomb)}");

            // 9. Feladat
            Console.WriteLine($" 9. Írjuk ki a sorozatban található prímszámokat!");

            int seged;
            for (int i = 0; i < tomb.Length; i++)
            {
                seged = 0;
                for (int j = 2; j < 30; j++)
                {
                    if (tomb[i] % j != 0)
                    {
                        seged++;
                    }
                }
                if (seged == 27)
                {
                    Console.WriteLine($" {tomb[i]}");
                }
            }

            // 10. Feladat
            Console.WriteLine($" 10. Mennyi a sorozatban található legátlagosabb szám? (legkevésbé tér el az átlagtól) {legatlag(tomb)}");


            Console.ReadKey();
        }
    }
}

﻿using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
		void Ötszög()
        {
			for (int i = 0; i < 5; i++)
			{
				Előre(8);
				Jobbra(72);
			}
			Jobbra(36);
			Tollat(fel);
			Előre(5);
			Tölt(Color.DeepPink);
			Hátra(5);
			Tollat(le);
			Balra(36);
		}

		void Legyező()
        {
			
			Előre(100);
			Jobbra(90);


			for (int i = 0; i < 15; i++)
			{
				Előre(2);
				Jobbra(1);
			}
			for (int i = 0; i < 15; i++)
			{
				Balra(1);
				Hátra(2);
			}

			Balra(90);
			Hátra(100);


			Jobbra(18);
			Előre(100);
			Hátra(100);

			Balra(13);
			Tollat(fel);
			Előre(75);
			Tollat(le);
			Ötszög();
			Tollat(fel);
			Hátra(75);
			Tollat(le);
			Jobbra(13);
		}
		void Legyező(int db)
        {
            for (int i = 0; i < db; i++)
            {
				Legyező();
            }
        }
		void FELADAT()
		{
			Balra(90);
			Legyező(10);
		}
	}
}

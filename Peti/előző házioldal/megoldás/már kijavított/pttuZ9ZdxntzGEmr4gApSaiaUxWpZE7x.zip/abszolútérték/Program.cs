﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abszolútérték
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Kérlek, adj meg egy számot, megadom az abszolút mértéket");
            int szam = int.Parse(Console.ReadLine());
            Console.WriteLine(Math.Abs(szam));


        }
    }
}

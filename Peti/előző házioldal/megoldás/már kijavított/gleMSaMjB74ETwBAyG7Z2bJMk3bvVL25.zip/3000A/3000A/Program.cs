﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _3000A
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] tömb = File.ReadAllLines("PT-3000A.txt");
            int[] számtömb = new int[tömb.Length];
            for (int i = 0; i < tömb.Length; i++)
            {
                számtömb[i] = int.Parse(tömb[i]);
            }

            // 1. Feladat
            {
                Console.WriteLine(" 1. Hány eleme van a sorozatnak? ");
                Console.WriteLine($" {tömb.Length}");
            }

            // 2. Feladat
            {
                Console.WriteLine(" 2. Van-e a sorozatban negatív szám? ");
                int i = 0;
                while (i < számtömb.Length && !(számtömb[i] < 0))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine(" Van");
                }
                else
                {
                    Console.WriteLine(" Nincs");
                }
            }

            // 3. Feladat
            {
                Console.WriteLine(" 3. Hány páros szám található a sorozatban?");
                int db = 0;
                for (int i = 0; i < számtömb.Length; i++)
                {
                    if (számtömb[i] % 2 == 0)
                    {
                        db++;
                    }
                }
                Console.WriteLine($" Enniy db páros szám található: {db}");
            }

            // 4. Feladat
            {
                Console.WriteLine(" 4. Mennyi a sorozatban található legnagyobb szám?");
                int max = számtömb[0]; 
                
                for (int i = 1; i < számtömb.Length; i++)
                {
                    if (max < számtömb[i])  
                    {
                        max = számtömb[i];
                    }
                }
                Console.WriteLine($" {max}");
            }

            // 5. Feladat
            {
                Console.WriteLine(" 5. Írjuk ki a sorozatban található 10-zel osztható számokat!");
                for (int i = 0; i < számtömb.Length; i++)
                {
                    if (számtömb[i] % 10 == 0)
                    {
                        Console.WriteLine($" {számtömb[i]}");
                    }
                }
            }

            // 6. Feladat
            {
                Console.WriteLine(" 6. Írjuk ki az első 29-cel osztható szám indexét!");
                int i = 0;
                while (i < számtömb.Length && !(számtömb[i] % 29 == 0))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine($" {i}");
                }
            }

            // 7. Feladat
            {
                Console.WriteLine(" 7. Igaz-e, hogy minden szám páros?");
                int i = 0;
                while (i < számtömb.Length && !(számtömb[i] % 2 == 1))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine(" Hamis");
                }
                else
                {
                    Console.WriteLine(" Igaz");
                }
            }

            // 8. Feladat
            {
                Console.WriteLine(" 8. Mennyi a sorozatban található számok átlaga?");
                int számok_összege = 0;
                int db = 0;
                for (int i = 0; i < 4; i++)
                {
                    számok_összege += számtömb[i];
                    db++;
                }
                int átlag = számok_összege / db;
                Console.WriteLine($" {átlag}");
            }

            // 9. Feladat
            {
                Console.WriteLine(" 9. Van-e a sorozatban olyan negatív szám, amelyet nulla követ?");
                int i = 1;
                while (i < számtömb.Length && !(számtömb[i] == 0 && számtömb[i - 1] < 0))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine(" Van");
                }
                else
                {
                    Console.WriteLine(" Nincs");
                }
            }

            // 10. Feladat
            {
                Console.WriteLine(" 10. Írjuk ki az utolsó 17-tel osztható szám indexét!");
                int i = számtömb.Length - 1;
                while (i >= 0 && !(számtömb[i] % 17 == 0))
                {
                    i--;
                }
                if (i >= 0)
                {
                    Console.WriteLine($" {i}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilyen");
                }
            }


            Console.ReadKey();
        }
    }
}

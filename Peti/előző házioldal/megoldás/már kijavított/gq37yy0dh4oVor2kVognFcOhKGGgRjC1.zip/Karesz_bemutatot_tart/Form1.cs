﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;


namespace Karesz
{
    public partial class Form1 : Form
    {

        /// <summary>
        /// Karesz lerak egy követ és ezt követően lép egyet. Ha már van itt kő, akkor a szokásos hibaüzenetet adja.
        /// </summary>
        void Kövezz()
        {
            Tegyél_le_egy_kavicsot();
            Lépj();
        }

        /// <summary>
        /// Karesz húz egy olyan hosszú csíkot kövekből, amekkorát megadtak.
        /// </summary>
        /// <param name="lepesszam">A kövekkel kirakott csík hossza.</param>
        void Kövezz(int lepesszam)
        {
            for (int i = 0; i < lepesszam; i++)
            {
                Tegyél_le_egy_kavicsot();
                Lépj();
            }
        }

        /// <summary>
        /// Karesz húz egy olyan hosszú olyan színű csíkot kövekből, amekkorát megadtak.
        /// </summary>
        /// <param name="lepesszam">A kövekkel kirakott csík hossza.</param>
        /// <param name="szín">A kő színe</param>
        void Kövezz(int lepesszam, int szín)
        {
            for (int i = 0; i < lepesszam; i++)
            {
                Tegyél_le_egy_kavicsot(szín);
                Lépj();
            }
        }


        /// <summary>
        /// Oldalazás: Karesz a megadott irányba (jobbra/balra) lép annyit, amennyit lépésszámnak megadnak.
        /// </summary>
        /// <param name="irany">jobbra vagy balra</param>
        /// <param name="lepesszam">Mennyit oldalazzon</param>
        void Lépj(int szam)
        {
            for (int i = 0; i < szam; i++)
            {
                Lépj();
            }
        }
        void Oldalazz(int irany, int lepesszam)
        {
            Fordulj(irany);
            Lépj(lepesszam);
            Fordulj(irany);
            Fordulj(irany);
            Fordulj(irany);
        }


        /// <summary>
        /// Karesz átlósan mozog a megadott irányban a megadott mennyiséget. 
        /// Pl. Átlózz(jobbra, 1, 10) azt jelenti, hogy jobbra-előre átlósan lép 10-et.
        /// Átlózz(jobbra,-1, 5) parancs hatására jobbra-hátra lépeget 5 lépést.
        /// </summary>
        /// <param name="vizszintes_irany"></param>
        /// <param name="fuggoleges_irany"></param>
        /// <param name="lepesszam"></param>
        void Átlózz(int vizszintes_irany, int fuggoleges_irany, int lepesszam)
        {
            for (int i = 0; i < lepesszam; i++)
            {
                Fordulj(vizszintes_irany);
                Lépj();
                Fordulj(vizszintes_irany);
                Fordulj(vizszintes_irany);
                Fordulj(vizszintes_irany);
                Lépj();
            }
        }

        /// <summary>
        /// Karesz fekete kövekkel kirak egy a szélességű és b magasságú téglalapot.
        /// </summary>
        /// <param name="a">szélesség</param>
        /// <param name="b">magasság</param>
        void Teglalap(int a, int b)
        {
            for (int j = 0; j < 2; j++)
            {
                for (int i = 0; i < a; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot(fekete);
                }
                Fordulj_jobbra();
                for (int i = 0; i < b; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot(fekete);
                }
                Fordulj_jobbra();
            }
        }
        /// <summary>
        /// Karesz a megadott színű kövekkel kirak egy a szélességű és b magasságú téglalapot. 
        /// (Ha Karesz Keletre vagy Nyugatra néz, akkor az a jó, ha téglalap szélessége is magasság, és a magasság is szélességgé válik.)
        /// </summary>
        /// <param name="a">szélesség</param>
        /// <param name="b">magasság</param>
        /// <param name="szin"></param>
        void Teglalap(int a, int b, int szin)
        {
            for (int j = 0; j < 2; j++)
            {
                for (int i = 0; i < a; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot(szin);
                }
                Fordulj_jobbra();
                for (int i = 0; i < b; i++)
                {
                    Lépj();
                    Tegyél_le_egy_kavicsot(szin);
                }
                Fordulj_jobbra();
            }
        }

        void FELADAT()
        {
            // Itt egy olyan kód legyen, ami a tanárnak/mentornak megmutatja, hogy tényleg sikerült megcsinálni a függvényeket!
            // Több különböző paraméterezés is legyen, és a különböző függvénymeghívásokat egy felugró ablakkal válaszd el, ami elmagyarázza, hogy Karesz most mit fog csinálni.
            // pl.:
            MessageBox.Show("Karesz most oldalazni fog 10-et jobbra: ");
            Oldalazz(jobbra, 10);
            MessageBox.Show("Karesz most meggondolja magát és visszaoldalaz balra 7-et: ");
            Oldalazz(balra, 7);
            // ... és így tovább ...
            MessageBox.Show("Karesz húz egy 7 kő hosszú csíkot");
            Kövezz(7);
            MessageBox.Show("Karesz húz egy 5 kő hosszú piros csíkot");
            Kövezz(5, piros);
            MessageBox.Show("Karesz oldalazni fog jobbra négyet");
            Oldalazz(jobbra, 4);
            MessageBox.Show("Karesz átlózni fog jobbra, felfele hat egységnyit");
            Átlózz(jobbra, 1, 6);
            MessageBox.Show("Karesz elfordul jobbra");
            Fordulj_jobbra();
            MessageBox.Show("Karesz kirak egy 7 kő széllességű és 4 kő magasságú téglalapot");
            Teglalap(6, 3);
            MessageBox.Show("Karesz lép előre 10-et");
            Lépj(10);
            MessageBox.Show("Karesz először előre 4-et és utánna oldalra 5-öt lép, és így kirak egy sárga téglalapot");
            Teglalap(3, 4, sárga);
        }
    }
}
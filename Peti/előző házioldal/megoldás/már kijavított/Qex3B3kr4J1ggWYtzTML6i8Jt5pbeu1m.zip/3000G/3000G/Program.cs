﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _3000G
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] tömb = File.ReadAllLines("3000G.txt");
            int[] számtömb = new int[tömb.Length];
            for (int i = 0; i < tömb.Length; i++)
            {
                számtömb[i] = int.Parse(tömb[i]);
            }


            // 1. Feladat
            {
                Console.WriteLine(" 1. Hány eleme van a sorozatnak?");
                Console.WriteLine($" {számtömb.Length}");
            }

            // 2. Feladat
            {
                Console.WriteLine(" 2. Írjuk ki az utolsó [-10,10] zárt intervallumba eső szám indexét!");
                int i = számtömb.Length - 1;
                while (0 <= i && !(-10 <= számtömb[i] && számtömb[i] <= 10))
                {
                    i--;
                }
                if (0 <= i)
                {
                    Console.WriteLine($" {i}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilyen szám");
                }
            }

            // 3. Feladat
            {
                Console.WriteLine(" 3. Igaz-e, hogy minden szám 100-nál kisebb?");
                int i = 0;
                while (i < számtömb.Length && 100 <= számtömb[i])
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine(" Nem");
                }
                else
                {
                    Console.WriteLine(" Igen");
                }
            }

            // 4. Feladat
            {
                Console.WriteLine(" 4. Írjuk ki az első 3-mal és 5-tel osztható számot!");
                int i = 0;
                while (i < számtömb.Length && !(számtömb[i] % 3 == 0 && számtömb[i] % 5 == 0))
                {
                    i++;
                }
                if (i < számtömb.Length)
                {
                    Console.WriteLine($" {számtömb[i]}");
                }
                else
                {
                    Console.WriteLine(" Nincs ilyen szám");
                }
            }

            // 5. Feladat
            {
                Console.WriteLine(" 5. Mennyi a sorozatban található számok számtani közepe?");
                double sum = 0;
                for (int i = 0; i < számtömb.Length; i++)
                {
                    sum += számtömb[i];
                }
                Console.WriteLine($" {sum / számtömb.Length}");
            }

            // 6. Feladat
            {
                Console.WriteLine(" 6. Van-e a sorozatban köbszám?");
                bool köb_e(int n)
                {
                    for (int i = 0; i < n; i++)
                    {
                        if (i * i * i == n)
                        {
                            return true;
                        }
                    }

                    return false;
                }

                int j = 0;
                while (j < számtömb.Length && !(köb_e(számtömb[j])))
                {
                    j++;
                }
                if (j < számtömb[j])
                {
                    Console.WriteLine(" Van");
                }
                else
                {
                    Console.WriteLine(" Nincs");
                }
            }

            // 7. Feladat
            {
                Console.WriteLine(" 7. Írjuk ki a sorozatban található négyzetszámok négyzetgyökét!");
                bool negyzet_e(int n)
                {
                    for (int i = 0; i < n; i++)
                    {
                        if (i * i == n)
                        {
                            return true;
                        }
                    }

                    return false;
                }
                for (int i = 0; i < számtömb.Length; i++)
                {
                    if (negyzet_e(számtömb[i]))
                    {
                        Console.WriteLine($" {Math.Sqrt(számtömb[i])}");
                    }
                }
            }

            // 8. Feladat
            {
                Console.WriteLine(" 8. Van-e a sorozatban olyan negatív szám, amelyet két nulla követ?");
                int i = 2;
                while (i < számtömb[i] && !(számtömb[i - 2] < 0 && számtömb[i - 1] == 0 && számtömb[i] == 0))
                {
                    i++;
                }
                if (i < számtömb[i])
                {
                    Console.WriteLine(" Van.");
                }
                else
                {
                    Console.WriteLine(" Nincs.");
                }
            }

            // 9. Feladat
            {
                Console.WriteLine(" 9. Igaz-e, hogy a sorozat szigorúan monoton növő?");
                int i = 1;
                while (i < számtömb[i] && !(számtömb[i - 1] < számtömb[i]))
                {
                    i++;
                }
                if (i < számtömb[i])
                {
                    Console.WriteLine(" Nem");
                }
                else
                {
                    Console.WriteLine(" Igen");
                }
            }

            // 10. Feladat
            {
                Console.WriteLine(" 10. Mennyi a sorozatban található második legnagyobb szám?");
                List<int> maxi = new List<int>();
                int max = számtömb[0];
                for (int i = 0; i < számtömb.Length; i++)
                {
                    if (max < számtömb[i])
                    {
                        max = számtömb[i];
                        maxi.Add(számtömb[i]);
                    }
                }
                Console.WriteLine($" {maxi[maxi.Count - 2]}");
            }


            Console.ReadKey();
        }
    }
}

﻿using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
		void Piros_és_zöld_rész()
        {
			Előre(50);
			Jobbra(15);
			Előre(50);
			Jobbra(165);
			Előre(50);
			Jobbra(15);
			Előre(50);
			Jobbra(173);
			Tollat(fel);
			Előre(10);
			Tölt(Color.Red);
			Hátra(10);
			Tollat(le);
			Balra(8);

			Jobbra(30);

			Előre(25);
			Jobbra(15);
			Előre(25);
			Jobbra(165);
			Előre(25);
			Jobbra(15);
			Előre(25);
			Jobbra(173);
			Tollat(fel);
			Előre(10);
			Tölt(Color.Green);
			Hátra(10);
			Tollat(le);
			Balra(8);

			Jobbra(30);

		}

		void FELADAT()
		{
            for (int i = 0; i < 6; i++)
            {
				Piros_és_zöld_rész();
			}
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Karesz
{
    public partial class Form1 : Form
    {
        bool vége = false;
        void Irány_a_jobb_felső_sarok()
        {
            for (int i = 0; i < 2; i++)
            {
                while (!Kilépek_e_a_pályáról())
                {
                    Vegyél_fel_egy_kavicsot_ha_van();
                    Lépj();
                }
                if (Kilépek_e_a_pályáról())
                {
                    Fordulj(jobbra);
                    Vegyél_fel_egy_kavicsot_ha_van();
                }
            }
        }
        void Vegyél_fel_egy_kavicsot_ha_van()
        {
            if (Van_e_itt_kavics())
            {
                Vegyél_fel_egy_kavicsot();
            }
        }
        void FELADAT()
        {
            Irány_a_jobb_felső_sarok();

            while (!vége)
            {
                while (!Kilépek_e_a_pályáról())
                {
                    Vegyél_fel_egy_kavicsot_ha_van();
                    Lépj();
                    Vegyél_fel_egy_kavicsot_ha_van();
                }
                if (Kilépek_e_a_pályáról())
                {
                    Fordulj(jobbra);
                    if (Kilépek_e_a_pályáról())
                    {
                        vége = true;
                    }
                    else
                    {
                        Lépj();
                    }
                    Vegyél_fel_egy_kavicsot_ha_van();
                    Fordulj(jobbra);
                }
                while (!Kilépek_e_a_pályáról())
                {
                    Vegyél_fel_egy_kavicsot_ha_van();
                    Lépj();
                    Vegyél_fel_egy_kavicsot_ha_van();
                }
                if (Kilépek_e_a_pályáról())
                {
                    Fordulj(balra);
                    if (Kilépek_e_a_pályáról())
                    {
                        vége = true;
                    }
                    else
                    {
                        Lépj();
                    }
                    Vegyél_fel_egy_kavicsot_ha_van();
                    Fordulj(balra);
                }

            }

        }

    }
}
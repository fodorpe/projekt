﻿using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LogoKaresz
{
	public partial class Form1 : Form
	{
		void alap(double méret)
		{
			Ív(90, méret);
			Balra(90);
			Tollat(fel);
			Ív(90, -méret);
			Ív(90, -méret);
			Balra(90);
			Tollat(le);
			Ív(90, méret);
			Jobbra(90);
			Tollat(fel);
			Ív(90, méret);
			Tollat(le);
			Ív(180, méret);
			Tollat(fel);
			Jobbra(90);
			Ív(90, méret);
			Tollat(le);
			Jobbra(90);
		}
		void szem(double méret)
		{
			for (int i = 0; i < 4; i++)
			{
				alap(méret * 2);
			}
		}
		void helyre_áll(double méret)
		{
			Tollat(fel);
			Ív(90, méret);
			Balra(90);
			Ív(90, méret);
			Tollat(le);
			Balra(90);

		}
		void sor(int db, double méret)
		{
			for (int i = 0; i < db; i++)
			{
				szem(méret);
				helyre_áll(méret * 2);

			}

		}
		void helyre_áll_nagy(int db, double méret)
		{
			Jobbra(180);
			for (int i = 0; i < db; i++)
			{
				Tollat(fel);
				Ív(90, méret * 2);
				Balra(90);
				Ív(90, méret * 2);
				Balra(90);
			}
			Balra(90);
			Ív(90, méret * 2);
			Balra(90);
			Ív(90, méret * 2);
			Tollat(le);
			Jobbra(180);

		}
		void háló(int sorok_száma, int db, double méret)
		{
			for (int i = 0; i < sorok_száma; i++)
			{
				sor(db, méret);
				helyre_áll_nagy(db, méret);

			}


		}
		void FELADAT()
		{
			Tollat(fel);
			Előre(200);
			Tollat(le);
			háló(3, 4, 10);
		}

	}
}

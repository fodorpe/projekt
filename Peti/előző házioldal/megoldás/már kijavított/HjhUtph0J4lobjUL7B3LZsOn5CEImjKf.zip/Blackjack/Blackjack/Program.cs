﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Szabályok:");
            Console.WriteLine("Az Ász értéke 11");
            Console.WriteLine("A Jumbo, a Dáma és a Király értéke 10");
            Console.WriteLine("2 és 10 között a lapok értéke annyi, amennyi rájuk van írva");
            Console.WriteLine("");
            Console.WriteLine("Játékmenet:");
            Console.WriteLine("Először a osztó leoszt a játékosnak két lapot, majd magának is kettőt, egyiket fel-, másikat lefordítva.");
            Console.WriteLine("Utánna a játékos dönthet, hogy kér-e még, vagy sem, de max 2-szer kérhet.");
            Console.WriteLine("Ha a játékos kezének értéke végleges, akkor jön a bank. Húz magának.");
            Console.WriteLine("16-ig kötelező lapot kérnie");
            Console.WriteLine("17-től kötelező megállnia");

            Random rszg = new Random();

            List<int> jatekoslapjai = new List<int>();

            List<int> banklapjai = new List<int>();

            int jatekos_sum = 0;
            int bank_sum = 0;
            int bix = 0;
            int jix = 0;
            string valasz;

            for (int i = 0; i < 2; i++)
            {
                jatekoslapjai.Add(rszg.Next(1, 14));

                if (jatekoslapjai[jix] == 11 || jatekoslapjai[jix] == 12 || jatekoslapjai[jix] == 13)
                {
                    jatekoslapjai[jix] = 10;
                }
                if (jatekoslapjai[jix] == 1)
                {
                    jatekoslapjai[jix] = 11;
                }

                jatekos_sum += jatekoslapjai[jix];
                jix++;
            }
            while (bank_sum <= 16)
            {
                banklapjai.Add(rszg.Next(1, 14));

                if (banklapjai[bix] == 11 || banklapjai[bix] == 12 || banklapjai[bix] == 13)
                {
                    banklapjai[bix] = 10;
                }
                if (banklapjai[bix] == 1)
                {
                    banklapjai[bix] = 11;
                }
                if (bank_sum + banklapjai[bix] <= 21)
                {
                    bank_sum += banklapjai[bix];
                }
                else
                {
                    break;
                }

                bix++;
            }
            Console.WriteLine("");
            Console.WriteLine("Bank első lapja: {0}", banklapjai[0]);
            Console.WriteLine("Lapjaid értékének összege: {0}", jatekos_sum);
            Console.WriteLine("");
            while (jatekos_sum <= 21)
            {
                Console.WriteLine("Szeretnél húzni? (igen / nem)");
                valasz = Console.ReadLine();
                if (valasz == "igen")
                {
                    jatekoslapjai.Add(rszg.Next(1, 14));

                    if (jatekoslapjai[jix] == 11 || jatekoslapjai[jix] == 12 || jatekoslapjai[jix] == 13)
                    {
                        jatekoslapjai[jix] = 10;
                    }
                    if (jatekoslapjai[jix] == 1)
                    {
                        jatekoslapjai[jix] = 11;
                    }
                    jatekos_sum += jatekoslapjai[jix];

                    jix++;

                    Console.WriteLine("");
                    if (jatekos_sum <= 21)
                    {
                        Console.WriteLine("Lapjaid értékének összege: {0}", jatekos_sum);
                    }
                    else
                    {
                        Console.WriteLine("Túlmentél");
                        Console.WriteLine("({0})", jatekos_sum);
                    }
                    Console.WriteLine("");
                }
                else if (valasz == "nem")
                {
                    Console.WriteLine("");
                    if (jatekos_sum < bank_sum)
                    {
                        Console.WriteLine("Vesztettél");
                        Console.WriteLine("");
                        Console.WriteLine("A bank nyert {0}-{1}-ra", bank_sum, jatekos_sum);
                    }
                    else if (jatekos_sum > bank_sum)
                    {
                        Console.WriteLine("Nyertél {0}-{1}-ra", jatekos_sum, bank_sum);
                    }
                    else if (jatekos_sum == bank_sum)
                    {
                        Console.WriteLine("Döntetlen ({0}-{1})", jatekos_sum, bank_sum);
                    }
                    Console.WriteLine("");

                    break;
                }
            }
        }
    }
}

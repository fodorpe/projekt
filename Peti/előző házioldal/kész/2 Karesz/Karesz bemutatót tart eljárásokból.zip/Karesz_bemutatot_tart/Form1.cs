﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;


namespace Karesz
{
    public partial class Form1 : Form
    {

        /// <summary>
        /// Karesz lerak egy követ és ezt követően lép egyet. Ha már van itt kő, akkor a szokásos hibaüzenetet adja.
        /// </summary>
        void Kövezz()
        {

        }

        /// <summary>
        /// Karesz húz egy olyan hosszú csíkot kövekből, amekkorát megadtak.
        /// </summary>
        /// <param name="lepesszam">A kövekkel kirakott csík hossza.</param>
        void Kövezz(int lepesszam)
        {

        }

        /// <summary>
        /// Karesz húz egy olyan hosszú olyan színű csíkot kövekből, amekkorát megadtak.
        /// </summary>
        /// <param name="lepesszam">A kövekkel kirakott csík hossza.</param>
        /// <param name="szín">A kő színe</param>
        void Kövezz(int lepesszam, int szín)
        {

        }


        /// <summary>
        /// Oldalazás: Karesz a megadott irányba (jobbra/balra) lép annyit, amennyit lépésszámnak megadnak.
        /// </summary>
        /// <param name="irany">jobbra vagy balra</param>
        /// <param name="lepesszam">Mennyit oldalazzon</param>
        void Oldalazz(int irany, int lepesszam)
        {
            // ide írd a kódot!
        }


        /// <summary>
        /// Karesz átlósan mozog a megadott irányban a megadott mennyiséget. 
        /// Pl. Átlózz(jobbra, 1, 10) azt jelenti, hogy jobbra-előre átlósan lép 10-et.
        /// Átlózz(jobbra,-1, 5) parancs hatására jobbra-hátra lépeget 5 lépést.
        /// </summary>
        /// <param name="vizszintes_irany"></param>
        /// <param name="fuggoleges_irany"></param>
        /// <param name="lepesszam"></param>
        void Átlózz(int vizszintes_irany, int fuggoleges_irany, int lepesszam)
        {
            // ide írd a kódot!
        }

        /// <summary>
        /// Karesz fekete kövekkel kirak egy a szélességű és b magasságú téglalapot.
        /// </summary>
        /// <param name="a">szélesség</param>
        /// <param name="b">magasság</param>
        void Teglalap(int a, int b)
        {
            // ide írd a kódot!
        }


        /// <summary>
        /// Karesz a megadott színű kövekkel kirak egy a szélességű és b magasságú téglalapot. 
        /// (Ha Karesz Keletre vagy Nyugatra néz, akkor az a jó, ha téglalap szélessége is magasság, és a magasság is szélességgé válik.)
        /// </summary>
        /// <param name="a">szélesség</param>
        /// <param name="b">magasság</param>
        /// <param name="szin"></param>
        void Teglalap(int a, int b, int szin)
        {
            // ide írd a kódot!
        }

        void FELADAT()
        {
            // Itt egy olyan kód legyen, ami a tanárnak/mentornak megmutatja, hogy tényleg sikerült megcsinálni a függvényeket!
            // Több különböző paraméterezés is legyen, és a különböző függvénymeghívásokat egy felugró ablakkal válaszd el, ami elmagyarázza, hogy Karesz most mit fog csinálni.
            // pl.:
            MessageBox.Show("Karesz most oldalazni fog 10-et jobbra: ");
            Oldalazz(jobbra, 10);
            MessageBox.Show("Karesz most meggondolja magát és visszaoldalaz balra 7-et: ");
            Oldalazz(balra, 7);
            // ... és így tovább ...
        }
    }
}